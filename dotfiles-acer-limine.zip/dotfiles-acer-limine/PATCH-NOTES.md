# Patch notes — Acer / Omarchy / Limine

Files changed from the uploaded dotfiles repository:

- `nix/modules/hosts/nectarine-tree.nix`: `disko` → `acer-storage`; `secure-boot` → `limine-external-boot`; remove Lenovo facter report and fixed monitor XML; enable Intel microcode and redistributable firmware.
- `nix/modules/users/ruhtra.nix`: remove `secure-boot` include so Lanzaboote is not activated through the user aspect.
- `nix/modules/features/acer-storage.nix`: new explicit LUKS/LVM/Btrfs mount configuration for the new NixOS partition and shared existing ESP. Contains one LUKS UUID placeholder to be filled after formatting p3.
- `nix/modules/features/limine-external-boot.nix`: new NixOS external bootloader hook; writes only to `/boot/EFI/NixOS/` and checks `/boot` is ESP UUID `A282-91EC`.
- `README.md`: adds the dual-boot guide warning.

Preserved: `flake.nix`, `flake.lock`, all original user wrappers/dotfiles, most host/user aspects, secrets, and the original impermanence subvolume names. The original Disko definitions remain in the repository for historical/other-host use but are no longer included by this Acer host.

Validation note: the bundle was statically inspected and diffed, but could not be evaluated with `nix flake check` in this build environment because the Nix CLI is not installed here. Run a flake evaluation/build from the NixOS installer before formatting or installing if you want an additional validation gate.
