{
  flake.wrappers.waybar = {
    "style.css".content = builtins.concatStringsSep "" [
      (builtins.readFile ./style.css)
      (builtins.readFile ./mocha.css)
    ];
  };
}
