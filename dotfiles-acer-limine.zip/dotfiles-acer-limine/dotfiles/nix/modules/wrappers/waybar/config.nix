{
  flake.wrappers.waybar = {
    settings = {
      layer = "top";
      height = 10;
      spacing = 5;
      modules-left = [
        "hyprland/workspaces"
      ];
      modules-right = [
        "battery"
        "disk"
        "memory"
        "network"
        "backlight"
        "pulseaudio"
        "idle_inhibitor"
        "user"
        "custom/screen-time"
        "clock"
      ];
    };
  };
}
