{
  flake.wrappers.himalaya.settings = {
    accounts = {
      icloud = {
        default = true;
        email = "arthur_johannes@icloud.com";
        display-name = "arthur_johannes";
        downloads-dir = "/home/ruhtra/Downloads";
        backend = {
          type = "imap";
          host = "imap.mail.me.com";
          port = 993;
          login = "arthur_johannes";
          encryption.type = "tls";
          auth = {
            type = "password";
            command = "pa show icloud-mail | head -n 1";
          };
        };
        message.send.backend = {
          type = "smtp";
          host = "smtp.mail.me.com";
          port = 587;
          login = "arthur_johannes@icloud.com";
          encryption.type = "tls";
          auth = {
            type = "password";
            command = "pa show icloud-mail | head -n 1";
          };
        };
        folder.aliases = {
          inbox = "INBOX";
          trash = "Deleted Messages";
          sent = "Sent Messages";
          drafts = "Drafts";
        };
      };
      iserv = {
        default = false;
        email = "arthur.hargassner@grootmoor.net";
        display-name = "arthur.hargassner";
        downloads-dir = "/home/ruhtra/Downloads";
        backend = {
          type = "imap";
          host = "grootmoor.net";
          port = 993;
          login = "arthur.hargassner";
          encryption.type = "tls";
          auth = {
            type = "password";
            command = "pa show iserv-grootmoor | head -n 1";
          };
        };
        message.send.backend = {
          type = "smtp";
          host = "grootmoor.net";
          port = 465;
          login = "arthur.hargassner";
          encryption.type = "tls";
          auth = {
            type = "password";
            command = "pa show iserv-grootmoor | head -n 1";
          };
        };
        folder.aliases = {
          inbox = "INBOX";
          trash = "INBOX/Trash";
          sent = "INBOX/Sent";
          drafts = "INBOX/Drafts";
        };
      };
    };
  };
}
