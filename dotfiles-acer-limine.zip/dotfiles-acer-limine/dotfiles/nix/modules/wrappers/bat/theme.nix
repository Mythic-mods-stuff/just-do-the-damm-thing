{
  flake.wrappers.bat.themes = {
    catppuccin-mocha.path = ./themes/Catppuccin_Mocha.tmTheme;
    catppuccin-macchiato.path = ./themes/Catppuccin_Macchiato.tmTheme;
    catppuccin-frappe.path = ./themes/Catppuccin_Frappe.tmTheme;
    catppuccin-latte.path = ./themes/Catppuccin_Latte.tmTheme;
  };
}
