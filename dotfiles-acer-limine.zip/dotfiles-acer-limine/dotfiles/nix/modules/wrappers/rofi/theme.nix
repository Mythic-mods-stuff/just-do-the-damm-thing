{
  flake.wrappers.rofi =
    { lib, config, ... }:
    {
      theme = "${placeholder "out"}/share/rofi/themes/catppuccin-mocha.rasi";
      constructFiles = lib.pipe ./themes [
        builtins.readDir
        (lib.filterAttrs (name: value: value == "regular"))
        # builtins.attrNames
        (lib.concatMapAttrs (
          name: _: {
            ${name} = {
              content = builtins.readFile ./themes/${name};
              relPath = "share/rofi/themes/${name}";
            };
          }
        ))
      ];
    };
}
