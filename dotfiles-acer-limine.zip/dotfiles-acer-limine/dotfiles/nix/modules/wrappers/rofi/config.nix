{
  flake.wrappers.rofi = {
    settings = {
      modi = "combi,drun,nix-run:~/dotfiles/.config/rofi/nix-run.nu";
      combi-modes = "nix-run,drun";
      icon-theme = "Oranchelo";
      show-icons = true;
      terminal = "foot";
      drun-display-format = "{icon} {name}";
      location = 0;
      disable-history = false;
      hide-scrollbar = true;
      display-drun = "";
      display-run = "   Run ";
      display-window = " 󰕰  Window";
      display-combi = "   Run ";
    };
  };
}
