{
  flake.wrappers.jjui = (
    {
      config,
      lib,
      wlib,
      pkgs,
      ...
    }:
    let
      tomlFmt = pkgs.formats.toml { };
    in
    {
      imports = [ wlib.modules.default ];
      options = {
        settings = lib.mkOption {
          type = tomlFmt.type;
          default = { };
          description = ''
            Configuration options for jjui.
          '';
        };
      };
      config =
        let
          settings = tomlFmt.generate "config.toml" config.settings;
          config-dir = pkgs.runCommandLocal "${config.binName}-config" { } ''
            mkdir -p $out
            cp ${settings} $out/config.toml
          '';
        in
        {
          env.JJUI_CONFIG_DIR = config-dir;
          package = lib.mkDefault config.pkgs.jjui;
        };
    }
  );
}
