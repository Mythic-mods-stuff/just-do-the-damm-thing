{
  flake.wrappers.jjui.settings = {
    preview.revision_command = [
      "show"
      "--color"
      "always"
      "--tool"
      "difft"
      "-r"
      "$change_id"
    ];
  };
}
