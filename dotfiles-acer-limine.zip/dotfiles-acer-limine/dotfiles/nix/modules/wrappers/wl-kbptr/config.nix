{
  flake.wrappers.wl-kbptr.settings = {
    general.modes = "floating,click";
    mode_floating = {
      source = "detect";
      label_symbols = "uiaeosnrtd";
      label_font_family = "Monaspace Krypton";
      selectable_bg_color = "#b4befeee";
      selectable_border_color = "#b4befeee";
      label_color = "#1e1e2e";
      label_select_color = "#0000";
      # unselectable_bg_color = "#1e1e2e55";
      unselectable_bg_color = "#cdd6f4bb";
    };
  };
}
