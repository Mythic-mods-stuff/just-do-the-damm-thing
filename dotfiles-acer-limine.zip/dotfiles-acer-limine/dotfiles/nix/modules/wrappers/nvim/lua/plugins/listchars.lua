return {
  {
    "listchars",
    event = "BufEnter",
    after = function(plugin)
      require("nvim-listchars").setup {
        save_state = true,
        listchars = {
          trail = "-",
          eol = "¶",
          tab = "» ",
          space = "·",
        },
        notifications = true,
        exclude_filetypes = {},
        lighten_step = 10,
      }
    end,
  },
}
