return {
  {
    "trouble.nvim",
    keys = {
      {
        "<leader>td",
        "<cmd>Trouble diagnostics<cr>",
        desc = "Trouble diagnostics",
      },
    },
    after = function(plugin)
      require("trouble").setup {}
    end,
  },
}
