local map = vim.keymap.set

-- Save with Ctrl-S
map("i", "<C-s>", "<C-o><cmd>w<cr>")
map("n", "<C-s>", "<cmd>w<cr>")

-- Exit with Ctrl-Q
map("n", "<C-q>", "<cmd>qa<cr>")

-- Clear highlights and dismiss notifications on search when pressing <Esc> in normal mode
map("n", "<Esc>", function()
	vim.cmd("nohlsearch")
	require("notify").dismiss()
end)

-- Make navigating windows easier
map("n", "<C-up>", "<C-w><C-k>")
map("n", "<C-down>", "<C-w><C-j>")
map("n", "<C-left>", "<C-w><C-h>")
map("n", "<C-right>", "<C-w><C-l>")

-- Make navigating buffers easier
map("n", "<S-left>", "<cmd>bp<cr>")
map("n", "<S-right>", "<cmd>bn<cr>")

-- Setup formatting keybind
map("n", "<leader>F", vim.lsp.buf.format, {
	desc = "Format buffer with LSP",
})

-- Setup notification dismissing
local function dismiss()
	require("notify").dismiss()
end

map("n", "<leader>d", dismiss, {
	desc = "Dismiss notifications",
})
map("i", "<C-d>", dismiss, {
	desc = "Dismiss notifications",
})

-- Enable code actions
map("n", "<leader>ca", function()
	vim.lsp.buf.code_action()
end)

-- Open lazy.nvim
map("n", "<leader>l", "<cmd>Lazy<cr>", {
	desc = "Open Lazy.nvim",
})

-- Open oil.nvim
map("n", "<leader>o", "<cmd>Oil --float<cr>", {
	desc = "Open Oil.nvim",
})

-- Select the whole file
map("n", "<C-S-a>", "ggVG")

-- Open grug-far
map("n", "<leader>rg", "<cmd>GrugFar<cr>", {
	desc = "Find and Replace",
})

-- Nerd font icon picker
local function nf(opts)
	local pickers = require("telescope.pickers")
	local finders = require("telescope.finders")
	local actions = require("telescope.actions")
	local action_state = require("telescope.actions.state")
	local conf = require("telescope.config").values
	opts = opts or {}
	local icons = vim.fn.readfile("/home/ruhtra/.config/nushell/nerdfont.txt")
	pickers.new(opts, {
		prompt_title = "Nerd Font Icons",
		finder = finders.new_table {
			results = icons,
		},
		sorter = conf.generic_sorter(opts),
		attach_mappings = function(prompt_bufnr)
			actions.select_default:replace(function()
				actions.close(prompt_bufnr)
				local selection = action_state.get_selected_entry()
				vim.api.nvim_put({ selection[1]:sub(1, 4) }, "", false, true)
			end)
			return true
		end
	}):find()
end
map("n", "<leader>sn", function()
	nf(require("telescope.themes").get_dropdown {})
end, {
	desc = "Nerd Font Icons",
})
