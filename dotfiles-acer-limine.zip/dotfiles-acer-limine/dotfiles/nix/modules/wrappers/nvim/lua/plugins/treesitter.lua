return {
  {
    "nvim-treesitter-context",
    dep_of = "nvim-treesitter",
  },
  {
    "nvim-treesitter",
    lazy = false,
    after = function(plugin)
      local parsers = require('nvim-treesitter').get_available()
      vim.api.nvim_create_autocmd('FileType', {
        pattern = parsers,
        callback = function()
          vim.treesitter.start()
        end,
      })
    end
  },
}
