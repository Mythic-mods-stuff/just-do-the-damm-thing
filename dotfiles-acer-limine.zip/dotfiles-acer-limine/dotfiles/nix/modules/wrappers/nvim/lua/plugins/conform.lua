return {
  {
    "conform.nvim",
    cmd = { "ConformInfo" },
    event = { "BufWritePre" },
    on_require = { "conform" },
    after = function(plugin)
      require("conform").setup {
        formatters_by_ft = {
          nix = {
            "treefmt",
          },
          nu = {
            "topiary_nu",
          },
          javascript = {
            "prettier",
          },
          vue = {
            "prettier",
          },
          ["html.vue"] = {
            "prettier",
          },
          typescript = {
            "prettier",
          },
        },
        formatters = {
          topiary_nu = {
            command = "topiary",
            args = { "format", "--language", "nu" }
          },
        },
      }
    end,
  },
}
