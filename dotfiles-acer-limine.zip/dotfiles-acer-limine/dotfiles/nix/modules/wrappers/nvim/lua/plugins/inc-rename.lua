return {
  {
    "inc-rename.nvim",
    command = "IncRename",
    keys = {
      {
        "<leader>rn",
        function()
          return ":IncRename " .. vim.fn.expand("<cword>")
        end,
        desc = "Rename the word under the cursor",
        expr = true,
      },
    },
    after = function(plugin)
      require("inc_rename").setup {
        preview_empty_name = true,
        save_in_cmdline_history = false,
      }
    end,
  },
}
