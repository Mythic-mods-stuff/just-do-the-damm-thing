return {
  {
    "telescope-fzf-native.nvim",
    dep_of = "telescope.nvim",
  },
  {
    "telescope-ui-select.nvim",
    dep_of = "telescope.nvim",
  },
  {
    "telescope.nvim",
    lazy = false,
    after = function(plugin)
      local telescope = require("telescope")
      telescope.setup {
        extensions = {
          ["ui-select"] = {
            require("telescope.themes").get_dropdown(),
          },
        },
      }
      telescope.load_extension("fzf")
      telescope.load_extension("ui-select")
      local builtin = require("telescope.builtin")
      local map = vim.keymap.set
      -- Misc
      map("n", "<leader>sgc", builtin.live_grep, {
        desc = "Live Grep",
      })
      map("n", "<leader>ss", builtin.builtin, {
        desc = "Builtin Pickers",
      })
      map("n", "<leader>sh", builtin.help_tags, {
        desc = "Help",
      })
      map("n", "<leader>sp", builtin.planets, {
        desc = "Planets"
      })
      map("n", "<leader>sf", builtin.find_files, {
        desc = "Files",
      })
      map("n", "<leader>s.", builtin.oldfiles, {
        desc = "Recent Files ('.' for repeat)",
      })
      map("n", "<leader><leader>", builtin.buffers, {
        desc = "Existing buffers",
      })
      map("n", "<leader>sw", builtin.grep_string, {
        desc = "Current Word",
      })

      -- LSP
      map("n", "<leader>sld", builtin.lsp_definitions, {
        desc = "Definition of current word",
      })
      map("n", "<leader>slt", builtin.lsp_type_definitions, {
        desc = "Definition of type of current word",
      })
      map("n", "<leader>sld", function()
        builtin.diagnostics {
          no_sign = true,
        }
      end, {
          desc = "Diagnostics",
        })
      map("n", "<leader>slr", builtin.lsp_references, {
        desc = "References"
      })
      map("n", "<leader>sls", builtin.lsp_document_symbols, {
        desc = "Symbols",
      })

      -- Vim
      map("n", "<leader>svf", builtin.filetypes, {
        desc = "Filetypes",
      })
      map("n", "<leader>svk", builtin.keymaps, {
        desc = "Keymaps",
      })
      map("n", "<leader>sva", builtin.autocommands, {
        desc = "Autocmds",
      })
      map("n", "<leader>svr", builtin.registers, {
        desc = "Registers",
      })
      map("n", "<leader>svo", builtin.vim_options, {
        desc = "Options",
      })
      map("n", "<leader>svj", builtin.jumplist, {
        desc = "Jumplist",
      })
      map("n", "<leader>svq", builtin.quickfix, {
        desc = "Quickfix",
      })
      map("n", "<leader>svs", builtin.colorscheme, {
        desc = "Colorscheme",
      })
      map("n", "<leader>svm", builtin.marks, {
        desc = "Marks",
      })
      map("n", "<leader>svh", builtin.command_history, {
        desc = "Command history",
      })
      map("n", "<leader>svc", builtin.commands, {
        desc = "Commands",
      })

      -- Git
      map("n", "<leader>sgs", function()
        builtin.git_status {
          git_icons = {
            added = " ",
            changed = " ",
            copied = " ",
            deleted = " ",
            renamed = " ",
            unmerged = " ",
            untracked = " ",
          },
        }
      end, {
          desc = "Status",
        })
      map("n", "<leader>sgf", builtin.git_files, {
        desc = "Files",
      })
      map("n", "<leader>sgl", builtin.git_commits, {
        desc = "Log",
      })
      map("n", "<leader>sgh", builtin.git_bcommits, {
        desc = "File history",
      })
      map("n", "<leader>sgb", builtin.git_branches, {
        desc = "Branches",
      })
      map("n", "<leader>/", builtin.current_buffer_fuzzy_find, {
        desc = "Current buffer fuzzy",
      })
    end,
  },
}
