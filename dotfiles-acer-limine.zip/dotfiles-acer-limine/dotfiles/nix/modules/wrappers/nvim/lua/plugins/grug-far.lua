return {
  {
    "grug-far.nvim",
    command = "GrugFar",
    after = function(plugin)
      require("grug-far").setup {}
    end,
  },
}
