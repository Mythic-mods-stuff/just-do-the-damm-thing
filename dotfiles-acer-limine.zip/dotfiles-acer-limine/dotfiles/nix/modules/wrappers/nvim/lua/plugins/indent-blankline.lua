return {
  {
    "indent-blankline.nvim",
    lazy = false,
    after = function(plugin)
      local highlight = {
        "RainbowRed",
        "RainbowYellow",
        "RainbowBlue",
        "RainbowOrange",
        "RainbowGreen",
        "RainbowViolet",
        "RainbowCyan",
      }
      require("ibl").setup {
        indent = {
          highlight = highlight
        },
        scope = {
          enabled = false,
        },
      }
    end,
  },
}
