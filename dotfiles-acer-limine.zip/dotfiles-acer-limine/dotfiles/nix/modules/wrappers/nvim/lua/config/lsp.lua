-- -- Use .git as the root marker
-- vim.lsp.config("*", {
--   root_dir = function(fname)
--     return vim.fs.dirname(vim.fs.find(".git", { path = fname, upward = true })[1] or fname)
--   end
-- })

local nixInfo = require(vim.g.nix_info_plugin_name)

vim.opt.rtp:prepend(nixInfo(nil, "info", "lspconfig"))

local function lspconfig(lsp, opts)
  if opts ~= nil then
    vim.lsp.config(lsp, opts)
  end
  vim.lsp.enable(lsp)
end

-- Miscellaneous
lspconfig("marksman")
lspconfig("metals")
lspconfig("nushell")
lspconfig("texlab")
lspconfig("tinymist", {
  settings = {
    formatterMode = "typstyle",
    exportPdf = "onType",
    typstExtraArgs = {
      "--creation-timestamp",
      tostring(os.date("%s")),
    },
  },
})

-- Python
lspconfig("ruff", {
  init_options = {
    settings = {
      configuration = "/home/ruhtra/.config/ruff.toml",
    },
  },
})
lspconfig("ty")

-- Lua
lspconfig("lua_ls", {
  on_init = function(client)
    if client.workspace_folders then
      local path = client.workspace_folders[1].name
      if path ~= vim.fn.stdpath("config") and (vim.fn.findfile(path .. ".luarc.json") ~= "" or vim.fn.findfile(path .. ".luarc.jsonc") ~= "") then
        return
      end
    end
    client.config.settings.Lua = vim.tbl_deep_extend("force", client.config.settings.Lua, {
      runtime = {
        version = "LuaJIT",
        path = {
          vim.fn.stdpath("config"),
        },
      },
      workspace = {
        checkThirdParty = false,
        library = {
          vim.env.VIMRUNTIME,
        },
      },
    })
  end,
  settings = {
    Lua = {},
  },
})

-- Nix
lspconfig("nixd")

-- Rust
lspconfig("rust_analyzer", {
  settings = {
    ["rust-analyzer"] = {
      check = {
        command = "clippy",
        workspace = false,
      },
    },
  },
})

-- JavaScript
--- Svelte
lspconfig("svelte", {
  cmd = { "bun", "svelteserver", "--stdio" }
})
--- Tailwind
-- lspconfig("tailwindcss", {
--   cmd = { "bun", "tailwindcss-language-server", "--stdio" },
-- })
--- Vue
local vue_language_server_path = nixInfo(nil, "info", "vue_ls")
local tsserver_filetypes = { 'typescript', 'javascript', 'javascriptreact', 'typescriptreact', 'typescript.tsx',
  'javascript.jsx', 'vue' }
local vue_plugin = {
  name = '@vue/typescript-plugin',
  location = vue_language_server_path,
  languages = { 'typescript', 'javascript', 'vue' },
  configNamespace = 'typescript',
}
-- lspconfig('vtsls', {
--   settings = {
--     vtsls = {
--       tsserver = {
--         globalPlugins = {
--           vue_plugin,
--         },
--       },
--     },
--   },
--   filetypes = tsserver_filetypes,
-- })
lspconfig('vue_ls', {})
lspconfig('ts_ls', {
  init_options = {
    plugins = {
      vue_plugin,
    },
  },
  filetypes = tsserver_filetypes,
})

-- HTML
lspconfig("emmet_language_server", {
  filetypes = { "css", "html", "nunjucks", "javascript", "javascriptreact", "less", "sass", "scss", "pug", "typescriptreact", "htmldjango" },
})

-- Go
lspconfig("gopls")
