return {
  {
    "vim-tmux-navigator",
    lazy = false,
    -- cmd = {
    --   "TmuxNavigateLeft",
    --   "TmuxNavigateDown",
    --   "TmuxNavigateUp",
    --   "TmuxNavigateRight",
    --   "TmuxNavigatePrevious",
    --   "TmuxNavigatorProcessList",
    -- },
    keys = {
      { "<c-left>",  "<cmd>set shell=bash<cr><cmd>TmuxNavigateLeft<cr><cmd>set shell=nu<cr>" },
      { "<c-down>",  "<cmd>set shell=bash<cr><cmd>TmuxNavigateDown<cr><cmd>set shell=nu<cr>" },
      { "<c-up>",    "<cmd>set shell=bash<cr><cmd>TmuxNavigateUp<cr><cmd>set shell=nu<cr>" },
      { "<c-right>", "<cmd>set shell=bash<cr><cmd>TmuxNavigateRight<cr><cmd>set shell=nu<cr>" },
      -- { "<c-\\>",    "<cmd><C-U>TmuxNavigatePrevious<cr>" },
    },
  },
}
