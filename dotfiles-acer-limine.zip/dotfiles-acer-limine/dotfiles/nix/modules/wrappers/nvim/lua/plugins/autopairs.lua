return {
  {
    "nvim-autopairs",
    event = "InsertEnter",
    after = function(plugin)
      require("nvim-autopairs").setup()
    end,
  },
}
