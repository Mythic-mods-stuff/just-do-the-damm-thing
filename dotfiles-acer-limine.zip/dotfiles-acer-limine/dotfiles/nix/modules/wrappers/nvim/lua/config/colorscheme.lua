local catppuccin = require("catppuccin")

catppuccin.setup {
  flavour = "mocha",
  integrations = {
    treesitter_context = true,
    noice = true,
    notify = true,
    telescope = {
      enabled = true,
    },
    lsp_trouble = true,
    indent_blankline = {
      scope_color = "sky",
      colored_indent_levels = true,
    },
  },
}

vim.cmd.colorscheme("catppuccin")
