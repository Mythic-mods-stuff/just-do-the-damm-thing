{ inputs, ... }:
{
  flake.wrappers.neovim =
    {
      wlib,
      lib,
      config,
      options,
      ...
    }:
    {
      options = {
        nvim-lib = {
          neovimPlugins = lib.mkOption {
            readOnly = true;
            type = lib.types.attrsOf wlib.types.stringable;
            default = config.nvim-lib.pluginsFromPrefix "plugins-" inputs;
          };
          pluginsFromPrefix = lib.mkOption {
            type = lib.types.raw;
            readOnly = true;
            default =
              prefix: inputs:
              lib.pipe inputs [
                builtins.attrNames
                (builtins.filter (s: lib.hasPrefix prefix s))
                (map (
                  input:
                  let
                    name = lib.removePrefix prefix input;
                  in
                  {
                    inherit name;
                    value = config.nvim-lib.mkPlugin name inputs.${input};
                  }
                ))
                builtins.listToAttrs
              ];
          };

        };
        settings.cats = lib.mkOption {
          readOnly = true;
          type = lib.types.attrsOf lib.types.bool;
          default = builtins.mapAttrs (_: v: v.enable) config.specs;
        };
      };
      config = {
        specMods = {
          options.runtimePkgs = options.runtimePkgs // {
            description = ''
              A runtimePkgs spec field to put packages on the PATH
              If the spec is disabled, this value will not be included in the resulting neovim derivation
            '';
          };
        };
        runtimePkgs = config.specCollect (acc: v: acc ++ (v.runtimePkgs or [ ])) [ ];
      };
    };
}
