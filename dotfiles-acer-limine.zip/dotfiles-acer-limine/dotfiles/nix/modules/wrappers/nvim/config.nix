{
  flake.wrappers.neovim =
    {
      pkgs,
      config,
      inputs',
      ...
    }:
    let
      mkLazySpec = plugins: {
        after = [ "lze" ];
        lazy = true;
        data = plugins;
      };
    in
    {
      settings = {
        config_directory = ./.;
        aliases = [ "panvim" ];
      };
      info = {
        lspconfig = pkgs.vimPlugins.nvim-lspconfig;
        vue_ls = "${pkgs.vue-language-server}/lib/language-tools/packages/language-server";
      };
      package = inputs'.neovim-nightly-overlay.packages.neovim;
      specs = {
        # lsp and runtime deps
        lsp = {
          data = null;
          runtimePkgs = [
            pkgs.nixd
            pkgs.tinymist
            pkgs.lua-language-server
            pkgs.vue-language-server
            pkgs.typescript-language-server
            pkgs.emmet-language-server
            pkgs.gopls
          ];
        };
        runtime = {
          data = null;
          runtimePkgs = [
            pkgs.typescript
            pkgs.nodejs
            pkgs.typstyle
            pkgs.tree-sitter
          ];
        };
        # Startup
        lze = [
          pkgs.vimPlugins.lze
          pkgs.vimPlugins.lzextras
        ];
        colorscheme = pkgs.vimPlugins.catppuccin-nvim;
        lib = [
          pkgs.vimPlugins.nvim-web-devicons
          pkgs.vimPlugins.nui-nvim
          pkgs.vimPlugins.plenary-nvim
        ];
        # Lazy
        treesitter = mkLazySpec [
          pkgs.vimPlugins.nvim-treesitter.withAllGrammars
          pkgs.vimPlugins.nvim-treesitter-context
          pkgs.vimPlugins.nvim-ts-autotag
          pkgs.vimPlugins.nvim-autopairs
        ];
        completion = mkLazySpec [
          pkgs.vimPlugins.blink-cmp
          pkgs.vimPlugins.friendly-snippets
          pkgs.vimPlugins.luasnip
        ];
        ui = mkLazySpec [
          pkgs.vimPlugins.indent-blankline-nvim
          pkgs.vimPlugins.lualine-nvim
          pkgs.vimPlugins.noice-nvim
          pkgs.vimPlugins.nvim-notify
          pkgs.vimPlugins.neoscroll-nvim
          pkgs.vimPlugins.oil-nvim
          pkgs.vimPlugins.trouble-nvim
        ];
        git = mkLazySpec [
          pkgs.vimPlugins.gitsigns-nvim
          pkgs.vimPlugins.diffview-nvim
          pkgs.vimPlugins.hunk-nvim
        ];
        utils = mkLazySpec [
          pkgs.vimPlugins.conform-nvim
          pkgs.vimPlugins.grug-far-nvim
          pkgs.vimPlugins.inc-rename-nvim
          config.nvim-lib.neovimPlugins.listchars
          pkgs.vimPlugins.mini-nvim
          pkgs.vimPlugins.markview-nvim
          pkgs.vimPlugins.which-key-nvim
          pkgs.vimPlugins.nvim-lilypond-suite
          pkgs.vimPlugins.blink-cmp-dictionary
          pkgs.vimPlugins.qmk-nvim
          pkgs.vimPlugins.vim-tmux-navigator
        ];
        telescope = mkLazySpec [
          pkgs.vimPlugins.telescope-nvim
          pkgs.vimPlugins.telescope-fzf-native-nvim
          pkgs.vimPlugins.telescope-ui-select-nvim
        ];
      };
    };
}
