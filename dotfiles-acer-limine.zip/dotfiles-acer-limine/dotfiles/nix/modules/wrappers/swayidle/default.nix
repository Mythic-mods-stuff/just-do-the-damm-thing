{ self, ... }:
{
  flake.wrappers.swayidle =
    { wlib, ... }:
    {
      imports = [
        wlib.wrapperModules.swayidle
        self.wrapperModules.inputs'
      ];
    };
}
