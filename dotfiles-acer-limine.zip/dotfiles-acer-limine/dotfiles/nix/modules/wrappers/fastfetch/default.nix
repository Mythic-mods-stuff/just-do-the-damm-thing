{
  flake.wrappers.fastfetch =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.fastfetch ];
    };
  flake.wrappers.fastfetch-logo =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.fastfetch ];
    };
}
