{
  flake.wrappers.fastfetch-logo = {
    binName = "fastfetch-logo";
    settings = {
      logo = { };
      modules = [ ];
    };
  };
}
