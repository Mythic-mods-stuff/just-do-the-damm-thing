{
  flake.wrappers.kickoff = {
    settings = {
      colors = {
        background = "#1e1e2eaa";
        prompt = "#b4befe";
        text = "#cdd6f4";
        text_query = "#cba6f7";
        text_selected = "#a6e3a1";
      };
      font_size = 30;
      fonts = [ "monospace" ];
      history.decrease_interval = 48;
      keybindings = {
        complete = [ "Tab" ];
        delete = [
          "KP_Delete"
          "Delete"
          "BackSpace"
        ];
        delete_word = [
          "ctrl+KP_Delete"
          "ctrl+Delete"
          "ctrl+BackSpace"
        ];
        execute = [
          "KP_Enter"
          "Return"
        ];
        exit = [ "Escape" ];
        nav_down = [ "Down" ];
        nav_up = [ "Up" ];
        paste = [ "ctrl+v" ];
      };
      padding = 100;
      prompt = "";
    };
  };
}
