{ self, ... }:
{
  flake-file.inputs.vibepanel = {
    url = "github:prankstr/vibepanel";
    inputs.nixpkgs.follows = "nixpkgs";
  };
  flake.wrappers.vibepanel =
    {
      wlib,
      pkgs,
      lib,
      config,
      inputs',
      ...
    }:
    let
      tomlFmt = pkgs.formats.toml { };
    in
    {
      imports = [
        wlib.modules.default
        self.wrapperModules.inputs'
      ];
      options = {
        settings = lib.mkOption {
          type = tomlFmt.type;
          default = { };
          description = ''
            Configuration options for vibepanel.
          '';
        };
      };
      config = {
        package = lib.mkDefault inputs'.vibepanel.packages.vibepanel;
        flags."--config" = config.constructFiles.generatedConfig.path;
        constructFiles.generatedConfig = {
          content = builtins.toJSON config.settings;
          relPath = "${config.binName}-config/config.toml";
          builder = ''mkdir -p "$(dirname "$2")" && ${pkgs.remarshal}/bin/json2toml "$1" "$2"'';
        };
      };
      meta.maintainers = [
        wlib.maintainers.appleptree
      ];
    };
}
