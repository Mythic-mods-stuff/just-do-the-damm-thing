{
  flake.wrappers.vibepanel = {
    settings = {
      bar = {
        size = 30;
        border_radius = 200;
      };
    };
  };
}
