{
  flake.wrappers.alacritty =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.alacritty ];
    };
}
