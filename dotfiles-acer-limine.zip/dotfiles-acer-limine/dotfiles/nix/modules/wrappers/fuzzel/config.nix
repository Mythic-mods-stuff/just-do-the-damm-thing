{
  flake.wrappers.fuzzel = {
    settings = {
      main.font = "monospace:size=8";
    };
  };
}
