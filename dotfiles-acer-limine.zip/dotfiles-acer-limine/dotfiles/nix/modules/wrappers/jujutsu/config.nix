{
  flake.wrappers.jujutsu = {
    settings = {
      user = {
        name = "Pancake Appletree";
        email = "git@appleptree.anonaddy.com";
      };
      ui = {
        merge-editor = "mergiraf";
        diff-instructions = false;
        diff-editor = [
          "nvim"
          "-c"
          "DiffEditor $left $right $output"
        ];
        diff-formatter = [
          "difft"
          "--color=always"
          "$left"
          "$right"
        ];
        default-command = "log";
        show-cryptographic-signatures = true;
      };
      aliases = {
        delta = [
          "diff"
          "--tool"
          "delta"
        ];
        tug = [
          "bookmark"
          "move"
          "--from"
          "closest_bookmark(@)"
          "--to"
          "closest_pushable(@)"
        ];
      };
      revset-aliases = {
        "closest_bookmark(to)" = "heads(::to & bookmarks())";
        "closest_pushable(to)" = "heads(::to & ~description(exact:\"\") & (~empty() | merges()))";
      };
      signing = {
        behavior = "own";
        backend = "ssh";
        key = "~/.ssh/id_ed25519.pub";
        backends.ssh.allowed-signers = "~/.ssh/allowed_signers";
      };
    };
  };
}
