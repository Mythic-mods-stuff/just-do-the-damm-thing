{
  flake.wrappers.jujutsu =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.jujutsu ];
    };
}
