{ self, ... }:
{
  flake.wrappers.bash =
    {
      wlib,
      lib,
      pkgs,
      config,
      ...
    }:
    {
      imports = [
        wlib.modules.default
        self.wrapperModules.inputs'
      ];
      options = {
        ".bashrc" = lib.mkOption {
          type = wlib.types.file {
            path = lib.mkOptionDefault config.constructFiles.generatedConfig.path;
          };
          default = { };
          description = ''
            Bash rc file sourced on interactive shell startup
          '';
        };
      };
      config = {
        package = pkgs.bash;
        flags."--rcfile" = config.".bashrc".path;
        constructFiles.generatedConfig = {
          content = config.".bashrc".content;
          relPath = "${config.binName}-config/.bashrc";
        };
      };
    };
}
