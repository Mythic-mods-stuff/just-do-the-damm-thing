{
  flake.wrappers.bash = {
    ".bashrc".content = ''
      eval "$(starship init bash)"
    '';
  };
}
