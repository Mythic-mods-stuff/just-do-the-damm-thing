{
  flake.wrappers.foot =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.foot ];
    };
}
