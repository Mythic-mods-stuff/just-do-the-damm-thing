{
  flake.wrappers.fish =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.fish ];
    };
}
