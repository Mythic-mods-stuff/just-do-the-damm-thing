{
  flake.wrappers.hyprlock =
    { config, ... }:
    {
      settings =
        let
          accent = config.colorscheme.palette.base07;
          accentAlpha = config.colorscheme.palette.base0E;
          base = config.colorscheme.palette.base00;
          text = config.colorscheme.palette.base05;
          surface0 = config.colorscheme.palette.base02;
          red = config.colorscheme.palette.base08;
          yellow = config.colorscheme.palette.base0A;
          font = "MonaspiceXe NF";
        in
        {
          general = {
            disable_loading_bar = true;
            hide_cursor = true;
          };

          background = {
            monitor = "";
            path = "$HOME/.config/background";
            blur_passes = 0;
            color = base;
          };

          label = [
            {
              monitor = "";
              text = "Layout: $LAYOUT";
              color = text;
              font_size = 25;
              font_family = font;
              position = "30, -30";
              halign = "left";
              valign = "top";
            }
            {
              monitor = "";
              text = "$TIME";
              color = text;
              font_size = 90;
              font_family = font;
              position = "-30, 0";
              halign = "right";
              valign = "top";
            }

            # DATE
            {
              monitor = "";
              text = "cmd[update:43200000] date +\"%A, %d %B %Y\"";
              color = text;
              font_size = 25;
              font_family = font;
              position = "-30, -150";
              halign = "right";
              valign = "top";
            }
          ];

          # USER AVATAR
          image = [
            {
              monitor = "";
              path = "$HOME/.face";
              size = 100;
              border_color = accent;
              position = "0, 75";
              halign = "center";
              valign = "center";
            }
          ];

          # INPUT FIELD
          input-field = [
            {
              monitor = "";
              size = "300, 60";
              outline_thickness = 4;
              dots_size = 0.2;
              dots_spacing = 0.2;
              dots_center = true;
              outer_color = accent;
              inner_color = surface0;
              font_color = text;
              fade_on_empty = false;
              placeholder_text = "<span foreground=\"#${text}\"><i>󰌾 Logged in as </i><span foreground=\"#${accentAlpha}\">$USER</span></span>";
              hide_input = false;
              check_color = accent;
              fail_color = red;
              fail_text = "<i>$FAIL <b>($ATTEMPTS)</b></i>";
              capslock_color = yellow;
              position = "0, -47";
              halign = "center";
              valign = "center";
            }
          ];
        };
    };
}
