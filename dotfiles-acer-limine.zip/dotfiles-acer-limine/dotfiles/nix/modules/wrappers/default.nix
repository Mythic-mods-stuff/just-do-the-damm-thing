{ inputs, ... }:
{
  imports = [
    inputs.wrapper-modules.flakeModules.default
  ];
  flake-file.inputs = {
    wrapper-modules = {
      url = "github:appleptree/nix-wrapper-modules/custom-wrappers";
      inputs.nixpkgs.follows = "nixpkgs";
    };
    nixpkgs-stable.url = "github:nixos/nixpkgs/nixos-25.11";
  };
  perSystem = { pkgs, ... }: {
    wrappers = {
      control_type = "exclude";
      packages = {
        colorscheme = true;
        inputs' = true;
      };
    };
  };
}
