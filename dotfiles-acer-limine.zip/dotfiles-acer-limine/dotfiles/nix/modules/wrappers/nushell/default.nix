{ self, ... }:
{
  flake.wrappers.nushell-pa =
    {
      wlib,
      lib,
      inputs',
      ...
    }:
    {
      imports = [
        wlib.wrapperModules.nushell
        self.wrapperModules.inputs'
      ];
      "config.nu".content = builtins.readFile ./passwordass.nu;
      prefixVar = [
        [
          "PATH"
          ":"
          "${lib.makeBinPath [
            inputs'.custom-packages.packages.passwordass
          ]}"
        ]
      ];
    };

  flake.wrappers.nushell =
    {
      wlib,
      config,
      pkgs,
      lib,
      self',
      ...
    }:
    {
      imports = [
        wlib.wrapperModules.nushell
        self.wrapperModules.inputs'
      ];
      "config.nu".content = builtins.readFile ./config.nu;
      "env.nu".content = builtins.readFile ./env.nu;
      prefixVar = [
        [
          "PATH"
          ":"
          "${lib.makeBinPath [
            pkgs.carapace
            pkgs.wtype
            pkgs.carapace-bridge
            pkgs.skim
            self'.packages.atuin
            pkgs.zoxide
            self'.packages.starship
            self'.packages.starship-transient
            pkgs.vivid
            pkgs.nix-your-shell
            pkgs.eza
            pkgs.television
            pkgs.nix-search-tv
            self'.packages.script-askpass
            pkgs.jc
          ]}"
        ]
      ];
      constructFiles = lib.pipe ./. [
        builtins.readDir
        (lib.filterAttrs (name: value: value == "regular"))
        (lib.mapAttrsToList (name: value: ./${name}))
        (builtins.filter (name: lib.hasSuffix ".nu" name))
        (files: files ++ [ ./ls-colors ])
        (map (name: {
          name = baseNameOf name;
          value = {
            content = builtins.readFile name;
            output = lib.mkOverride 0 config.constructFiles.generatedConfig.output;
            relPath = lib.mkOverride 0 "${dirOf config.constructFiles.generatedConfig.relPath}/${baseNameOf name}";
          };
        }))
        builtins.listToAttrs
      ];
    };
}
