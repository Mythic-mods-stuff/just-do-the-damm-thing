mkdir ~/.cache/starship
starship init nu | save -f ~/.cache/starship/init.nu

mkdir ~/.cache/zoxide
zoxide init nushell | save -f ~/.cache/zoxide/init.nu

mkdir ~/.cache/atuin
atuin init nu --disable-up-arrow | save -f ~/.cache/atuin/init.nu

$env.CARAPACE_BRIDGES = "zsh,fish,bash,inshellisense"
mkdir ~/.cache/carapace
carapace _carapace nushell | save -f ~/.cache/carapace/init.nu

mkdir ~/.cache/television
tv init nu | save -f ~/.cache/television/init.nu

mkdir ~/.cache/nix-your-shell
nix-your-shell nu | save -f ~/.cache/nix-your-shell/init.nu
