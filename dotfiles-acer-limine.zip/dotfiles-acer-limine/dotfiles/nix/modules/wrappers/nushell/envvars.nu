# if "SHLVL" in ($env | columns) {
#   $env.SHLVL = $env.SHLVL | into int | $in + 1
# } else {
#   $env.SHLVL = 1
# }
$env.LS_COLORS = (vivid generate catppuccin-mocha)
$env.EDITOR = "nvim"
$env.VISUAL = $env.EDITOR
$env.PATH = (
  $env.PATH
  | split row (char esep)
  | append "/home/ruhtra/.cargo/bin"
  | append "/home/ruhtra/.local/bin"
	| append "/home/ruhtra/.luarocks/bin"
)
def tprompt [] {
  (
    ^(which starship-transient | get path | get 0) prompt
    --cmd-duration $env.CMD_DURATION_MS
    $"--status=($env.LAST_EXIT_CODE)"
    --terminal-width (term size).columns
  )
}
$env.PROMPT_INDICATOR_VI_INSERT = $"(ansi red)❯(ansi yellow)❯(ansi green)❯(ansi reset) "
$env.PROMPT_INDICATOR_VI_NORMAL = $"(ansi cyan)❮❮❮(ansi reset) "

$env.TRANSIENT_PROMPT_COMMAND = {|| tprompt}
$env.RIP_GRAVEYARD = "/home/ruhtra/.trash"
$env.TOPIARY_CONFIG_FILE = ("/home/ruhtra/.config" | path join topiary languages.ncl)
$env.TOPIARY_LANGUAGE_DIR = ("/home/ruhtra/.config" | path join topiary languages)

$env.MANPAGER = "nvim +Man!"

# $env.SSH_ASKPASS = "script-askpass"
# $env.SSH_ASKPASS_REQUIRE = "prefer"
# $env.SSH_ASKPASS_PASS_TO_GET = "ssh/nectarine-tree"
