$env.config.hooks.pre_prompt = (
	$env.config.hooks.pre_prompt
	# direnv
	| append { ||
			if (which direnv | is-empty) {
				return
			}
			direnv export json | from json | default {} | load-env
		}
)

