{
  flake.wrappers.helix =
    { wlib, pkgs, ... }:
    {
      imports = [ wlib.wrapperModules.helix ];
      package = pkgs.helix;
    };
}
