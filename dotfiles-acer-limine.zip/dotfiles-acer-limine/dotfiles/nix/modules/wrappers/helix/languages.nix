{
  flake.wrappers.helix = {
    languages = {
      language = [
        {
          name = "python";
          language-servers = [
            "ruff"
            "basedpyright"
          ];
          auto-format = true;
          rulers = [
            79
          ];
        }
        {
          name = "toml";
          language-servers = [
            "taplo"
          ];
          auto-format = true;
        }
        {
          name = "common-lisp";
          file-types = [
            "kbd"
          ];
        }
        {
          name = "jsonc";
          file-types = [
            {
              glob = "waybar/config";
            }
            "jsonc"
          ];
        }
        {
          name = "css";
          file-types = [
            "rasi"
            "css"
          ];
        }
        {
          name = "nix";
          language-servers = [
            "nixd"
            "nil"
          ];
          formatter.command = "alejandra";
          auto-format = true;
        }
        {
          name = "jinja";
          language-id = "html";
          file-types = [
            {
              glob = "templates/**/*.html";
            }
          ];
          language-servers = [
            "vscode-html-language-server"
            "superhtml"
            "djlsp"
          ];
          auto-format = true;
        }
        {
          name = "c";
          file-types = [
            "c"
            "pov"
          ];
        }
      ];
      language-server = {
        djlsp = {
          command = "uv";
          args = [
            "run"
            "djlsp"
          ];
        };
        ruff = {
          command = "uv";
          args = [
            "run"
            "ruff"
            "server"
          ];
          config.settings.configuration = "~/.config/ruff.toml";
        };
        basedpyright = {
          command = "uv";
          args = [
            "run"
            "basedpyright-langserver"
            "--stdio"
          ];
        };
        pylsp.config.pylsp.plugins = {
          pycodestyle = {
            enabled = false;
          };
          mccabe = {
            enabled = false;
          };
          pyflakes = {
            enabled = false;
          };
        };
        taplo = {
          command = "taplo";
          args = [
            "lsp"
            "stdio"
          ];
        };
        nixd.command = "nixd";
      };
    };
  };
}
