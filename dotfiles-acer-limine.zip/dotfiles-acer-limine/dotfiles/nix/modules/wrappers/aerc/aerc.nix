{
  flake.wrappers.aerc = {
    settings = {
      #
      # aerc main configuration

      general = {
        #
        # Used as a default path for save operations if no other path is specified.
        # ~ is expanded to the current user home dir.
        #
        #default-save-path=

        # If set to "gpg", aerc will use system gpg binary and keystore for all crypto
        # operations. If set to "internal", the internal openpgp keyring will be used.
        # If set to "auto", the system gpg will be preferred unless the internal
        # keyring already exists, in which case the latter will be used.
        #
        # Default: auto
        pgp-provider = "gpg";

        # By default, the file permissions of accounts.conf must be restrictive and
        # only allow reading by the file owner (0600). Set this option to true to
        # ignore this permission check. Use this with care as it may expose your
        # credentials.
        #
        # Default: false
        #unsafe-accounts-conf=false

        # Output log messages to specified file. A path starting with ~/ is expanded to
        # the user home dir. When redirecting aerc's output to a file using > shell
        # redirection, this setting is ignored and log messages are printed to stdout.
        #
        log-file = "~/.local/state/aerc/aerc.log";

        # Only log messages above the specified level to log-file. Supported levels
        # are: trace, debug, info, warn and error. When redirecting aerc's output to
        # a file using > shell redirection, this setting is ignored and the log level
        # is forced to trace.
        #
        # Default: info
        #log-level=info

        # Disable IPC entirely. Don't run commands (including mailto:... and mbox:...)
        # in an existing aerc instance, and don't start an IPC server to allow
        # subsequent aerc instances to run commands in the current one.
        #
        # Default: false
        #disable-ipc=false

        # Don't run mailto:... commands over IPC; start a new aerc instance with the
        # composer instead.
        #
        # Default: false
        #disable-ipc-mailto=false
        #
        # Don't run mbox:... commands over IPC; start a new aerc instance with the mbox
        # file instead.
        #
        # Default: false
        #disable-ipc-mbox=false

        # Set the $TERM environment variable used for the embedded terminal.
        #
        # Default: xterm-256color
        #term=xterm-256color

        # Display OSC8 strings in the embedded terminal
        #
        # Default: false
        #enable-osc8=false

        # Default shell command to use for :menu. This will be executed with sh -c and
        # will run in an popover dialog.
        #
        # Any occurrence of %f will be replaced by a temporary file path where the
        # command is expected to write output lines to be consumed by :menu. Otherwise,
        # the lines will be read from the command's standard output.
        #
        # Examples:
        #   default-menu-cmd=fzf
        #   default-menu-cmd=fzf --multi
        #   default-menu-cmd=dmenu -l 20
        #   default-menu-cmd=ranger --choosefiles=%f
        #
        #default-menu-cmd=
      };
      ui = {
        #
        # Describes the format for each row in a mailbox view. This is a comma
        # separated list of column names with an optional align and width suffix. After
        # the column name, one of the '<' (left), ':' (center) or '>' (right) alignment
        # characters can be added (by default, left) followed by an optional width
        # specifier. The width is either an integer representing a fixed number of
        # characters, or a percentage between 1% and 99% representing a fraction of the
        # terminal width. It can also be one of the '*' (auto) or '=' (fit) special
        # width specifiers. Auto width columns will be equally attributed the remaining
        # terminal width. Fit width columns take the width of their contents. If no
        # width specifier is set, '*' is used by default.
        #
        # Default: flags:4,name<20%,subject,date>=
        #index-columns=flags:4,name<20%,subject,date>=

        #
        # Each name in index-columns must have a corresponding column-$name setting.
        # All column-$name settings accept golang text/template syntax. See
        # aerc-templates(7) for available template attributes and functions.
        #
        # Here are some examples to show the To field instead of the From field for
        # an email (modifying column-name):
        #
        # 1. a generic one
        #   column-name={{ .Peer | names | join ", " }}
        # 2. based upon the selected folder
        #   column-name={{if match .Folder "^(Gesendet|Sent)$"}}{{index (.To | names) 0}}{{else}}{{index (.From | names) 0}}{{end}}
        #
        # Default settings
        #column-flags={{.Flags | join ""}}
        #column-name={{index (.From | names) 0}}
        #column-subject={{.ThreadPrefix}}{{.Subject}}
        #column-date={{.DateAutoFormat .Date.Local}}

        #
        # String separator inserted between columns. When the column width specifier is
        # an exact number of characters, the separator is added to it (i.e. the exact
        # width will be fully available for the column contents).
        #
        # Default: "  "
        #column-separator="  "

        #
        # See time.Time#Format at https://godoc.org/time#Time.Format
        #
        # Default: 2006 Jan 02
        #timestamp-format=2006 Jan 02

        #
        # Index-only time format for messages that were received/sent today.
        # If this is empty, timestamp-format is used instead.
        #
        # Default: 15:04
        #this-day-time-format=15:04

        #
        # Index-only time format for messages that were received/sent within the last
        # 7 days. If this is empty, timestamp-format is used instead.
        #
        # Default: Jan 02
        #this-week-time-format=Jan 02

        #
        # Index-only time format for messages that were received/sent this year.
        # If this is empty, timestamp-format is used instead.
        #
        #Default: Jan 02
        #this-year-time-format=Jan 02

        #
        # Overrides timestamp-format for the message view.
        #
        # Default: 2006 Jan 02, 15:04 GMT-0700
        #message-view-timestamp-format=2006 Jan 02, 15:04 GMT-0700

        #
        # If set, overrides timestamp-format in the message view for messages
        # that were received/sent today.
        #
        #message-view-this-day-time-format=

        # If set, overrides timestamp-format in the message view for messages
        # that were received/sent within the last 7 days.
        #
        #message-view-this-week-time-format=

        #
        # If set, overrides *timestamp-format* in the message view for messages
        # that were received/sent this year.
        #
        #message-view-this-year-time-format=

        #
        # Width of the sidebar, including the border.
        #
        # Default: 22
        #sidebar-width=22

        #
        # Default split layout for message list tabs. The syntax is:
        #
        #       [<direction>] <size>
        #
        # <direction> is optional and defaults to horizontal. It can take one
        # of the following values: h, horiz, horizontal, v, vert, vertical.
        #
        # <size> is a positive integer representing the size (in terminal cells)
        # of the message list window.
        #
        #message-list-split=

        #
        # Message to display when viewing an empty folder.
        #
        # Default: (no messages)
        #empty-message=(no messages)

        # Message to display when no folders exists or are all filtered
        #
        # Default: (no folders)
        #empty-dirlist=(no folders)
        #
        # Value to set {{.Subject}} template to when subject is empty.
        #
        # Default: (no subject)
        #empty-subject=(no subject)

        # Enable mouse events in the ui, e.g. clicking and scrolling with the mousewheel
        #
        # Default: false
        #mouse-enabled=false

        #
        # Ring the bell when new messages are received
        #
        # Default: true
        #new-message-bell=true

        #
        # Template to use for Account tab titles
        #
        # Default: {{.Account}}
        #tab-title-account={{.Account}}

        #
        # Template to use for Composer tab titles
        #
        # Default: {{if .To}}to:{{index (.To | shortmboxes) 0}} {{end}}{{.SubjectBase}}
        #tab-title-composer={{if .To}}to:{{index (.To | shortmboxes) 0}} {{end}}{{.SubjectBase}}

        #
        # Template to use for Message Viewer tab titles
        #
        # Default: {{.Subject}}
        #tab-title-viewer={{.Subject}}

        # Marker to show before a pinned tab's name.
        #
        # Default: `
        #pinned-tab-marker='`'

        # Template for the left side of the directory list.
        # See aerc-templates(7) for all available fields and functions.
        #
        # Default: {{.Folder}}
        #dirlist-left={{.Folder}}

        # Template for the right side of the directory list.
        # See aerc-templates(7) for all available fields and functions.
        #
        # Default: {{if .Unread}}{{humanReadable .Unread}}{{end}}
        #dirlist-right={{if .Unread}}{{humanReadable .Unread}}{{end}}

        # Delay after which the messages are actually listed when entering a directory.
        # This avoids loading messages when skipping over folders and makes the UI more
        # responsive. If you do not want that, set it to 0s.
        #
        # Default: 200ms
        #dirlist-delay=200ms

        # Display the directory list as a foldable tree that allows to collapse and
        # expand the folders.
        #
        # Default: false
        #dirlist-tree=false

        # If dirlist-tree is enabled, set level at which folders are collapsed by
        # default. Set to 0 to disable.
        #
        # Default: 0
        #dirlist-collapse=0

        # List of space-separated criteria to sort the messages by, see *sort*
        # command in *aerc*(1) for reference. Prefixing a criterion with "-r "
        # reverses that criterion.
        #
        # Example: "from -r date"
        #
        #sort=

        # Moves to next message when the current message is deleted
        #
        # Default: true
        #next-message-on-delete=true

        # Automatically set the "seen" flag when a message is opened in the message
        # viewer.
        #
        # Default: true
        #auto-mark-read=true

        # The directories where the stylesets are stored. It takes a colon-separated
        # list of directories. If this is unset or if a styleset cannot be found, the
        # following paths will be used as a fallback in that order:
        #
        #   ${XDG_CONFIG_HOME:-~/.config}/aerc/stylesets
        #   ${XDG_DATA_HOME:-~/.local/share}/aerc/stylesets
        #   /nix/store/b1nis22ya1nhy5fh7axsm4948r3mqsnx-aerc-0.20.1/share/aerc/stylesets
        #
        #stylesets-dirs=

        # Uncomment to use box-drawing characters for vertical and horizontal borders.
        #
        # Default: "│" and "─"
        border-char-vertical = "│";
        border-char-horizontal = "─";

        # Sets the styleset to use for the aerc ui elements.
        #
        # Default: default
        styleset-name = "catppuccin-mocha";

        # Activates fuzzy search in commands and their arguments: the typed string is
        # searched in the command or option in any position, and need not be
        # consecutive characters in the command or option.
        #
        # Default: false
        #fuzzy-complete=false

        # How long to wait after the last input before auto-completion is triggered.
        #
        # Default: 250ms
        #completion-delay=250ms

        # The minimum required characters to allow auto-completion to be triggered after
        # completion-delay.
        #
        # Setting this to "manual" disables automatic completion, leaving only the
        # manually triggered completion with the $complete key (see aerc-binds(5) for
        # more details).
        #
        # Default: 1
        #completion-min-chars=1

        #
        # Global switch for completion popovers
        #
        # Default: true
        #completion-popovers=true

        # Uncomment to use UTF-8 symbols to indicate PGP status of messages
        #
        # Default: ASCII
        #icon-unencrypted=
        #icon-encrypted=✔
        #icon-signed=✔
        #icon-signed-encrypted=✔
        #icon-unknown=✘
        #icon-invalid=⚠

        # Reverses the order of the message list. By default, the message list is
        # ordered with the newest (highest UID) message on top. Reversing the order
        # will put the oldest (lowest UID) message on top. This can be useful in cases
        # where the backend does not support sorting.
        #
        # Default: false
        #reverse-msglist-order = false

        # Reverse display of the message threads. Default order is the initial
        # message is on the top with all the replies being displayed below. The
        # reverse option will put the initial message at the bottom with the
        # replies on top.
        #
        # Default: false
        #reverse-thread-order=false

        # Positions the cursor on the last message in the message list (at the
        # bottom of the view) when opening a new folder.
        #
        # Default: false
        #select-last-message=false

        # Sort the thread siblings according to the sort criteria for the messages. If
        # sort-thread-siblings is false, the thread siblings will be sorted based on
        # the message UID in ascending order. This option is only applicable for
        # client-side threading with a backend that enables sorting. Note that there's
        # a performance impact when sorting is activated.
        #
        # Default: false
        #sort-thread-siblings=false

        # Set the scroll offset in number of lines from the top and bottom of the
        # message list.
        #
        # Default: 0
        #msglist-scroll-offset = 0

        #
        # Enable a threaded view of messages. If this is not supported by the backend
        # (IMAP server or notmuch), threads will be built by the client.
        #
        # Default: false
        #threading-enabled=false

        # Force client-side thread building
        #
        # Default: false
        #force-client-threads=false

        # If no References nor In-Reply-To headers can be matched to build client side
        # threads, fallback to similar subjects.
        #
        # Default: false
        #threading-by-subject=false

        # Show thread context enables messages which do not match the current query (or
        # belong to the current mailbox) to be shown for context. These messages can be
        # styled separately using "msglist_thread_context" in a styleset. This feature
        # is not supported by all backends
        #
        # Default: false
        #show-thread-context=false

        # Debounce client-side thread building
        #
        # Default: 50ms
        #client-threads-delay=50ms

        #
        # Thread prefix customization:

        #
        # Customize the thread prefix appearance by selecting the arrow head.
        #
        # Default: ">"
        #thread-prefix-tip = ">"

        #
        # Customize the thread prefix appearance by selecting the arrow indentation.
        #
        # Default: " "
        #thread-prefix-indent = " "

        #
        # Customize the thread prefix appearance by selecting the vertical extension of
        # the arrow.
        #
        # Default: "│"
        #thread-prefix-stem = "│"

        #
        # Customize the thread prefix appearance by selecting the horizontal extension
        # of the arrow.
        #
        # Default: ""
        #thread-prefix-limb = ""

        #
        # Customize the thread prefix appearance by selecting the folded thread
        # indicator.
        #
        # Default: "+"
        #thread-prefix-folded = "+"

        #
        # Customize the thread prefix appearance by selecting the unfolded thread
        # indicator.
        #
        # Default: ""
        #thread-prefix-unfolded = ""

        #
        # Customize the thread prefix appearance by selecting the first child connector.
        #
        # Default: ""
        #thread-prefix-first-child = ""

        #
        # Customize the thread prefix appearance by selecting the connector used if
        # the message has siblings.
        #
        # Default: "├─"
        #thread-prefix-has-siblings = "├─"

        #
        # Customize the thread prefix appearance by selecting the connector used if the
        # message has no parents and no children.
        #
        # Default: ""
        #thread-prefix-lone = ""

        #
        # Customize the thread prefix appearance by selecting the connector used if the
        # message has no parents and has children.
        #
        # Default: ""
        #thread-prefix-orphan = ""

        #
        # Customize the thread prefix appearance by selecting the connector for the last
        # sibling.
        #
        # Default: "└─"
        #thread-prefix-last-sibling = "└─"

        #
        # Customize the reversed thread prefix appearance by selecting the connector for
        # the last sibling.
        #
        # Default: "┌─"
        #thread-prefix-last-sibling-reverse = "┌─"

        #
        # Customize the thread prefix appearance by selecting the connector for dummy
        # thread.
        #
        # Default: "┬─"
        #thread-prefix-dummy = "┬─"

        #
        # Customize the reversed thread prefix appearance by selecting the connector for
        # dummy thread.
        #
        # Default: "┴─"
        #thread-prefix-dummy-reverse = "┴─"

        #
        # Customize the reversed thread prefix appearance by selecting the first child
        # connector.
        #
        # Default: ""
        #thread-prefix-first-child-reverse = ""

        #
        # Customize the reversed thread prefix appearance by selecting the connector
        # used if the message has no parents and has children.
        #
        # Default: ""
        #thread-prefix-orphan-reverse = ""
      };
      statusline = {
        #
        # Describes the format for the status line. This is a comma separated list of
        # column names with an optional align and width suffix. See [ui].index-columns
        # for more details. To completely mute the status line except for push
        # notifications, explicitly set status-columns to an empty string.
        #
        # Default: left<*,center:=,right>*
        #status-columns=left<*,center:=,right>*

        #
        # Each name in status-columns must have a corresponding column-$name setting.
        # All column-$name settings accept golang text/template syntax. See
        # aerc-templates(7) for available template attributes and functions.
        #
        # Default settings
        #column-left=[{{.Account}}] {{.StatusInfo}}
        #column-center={{.PendingKeys}}
        #column-right={{.TrayInfo}} | {{cwd}}

        #
        # String separator inserted between columns.
        # See [ui].column-separator for more details.
        #
        #column-separator=" "

        # Specifies the separator between grouped statusline elements.
        #
        # Default: " | "
        #separator=" | "

        # Defines the mode for displaying the status elements.
        # Options: text, icon
        #
        # Default: text
        #display-mode=text
      };
      viewer = {
        #
        # Specifies the pager to use when displaying emails. Note that some filters
        # may add ANSI codes to add color to rendered emails, so you may want to use a
        # pager which supports ANSI codes.
        #
        # Default: less -Rc
        #pager=less -Rc

        #
        # If an email offers several versions (multipart), you can configure which
        # mimetype to prefer. For example, this can be used to prefer plaintext over
        # html emails.
        #
        # Default: text/plain,text/html
        #alternatives=text/plain,text/html

        #
        # Default setting to determine whether to show full headers or only parsed
        # ones in message viewer.
        #
        # Default: false
        #show-headers=false

        #
        # Layout of headers when viewing a message. To display multiple headers in the
        # same row, separate them with a pipe, e.g. "From|To". Rows will be hidden if
        # none of their specified headers are present in the message.
        #
        # Default: From|To,Cc|Bcc,Date,Subject
        #header-layout=From|To,Cc|Bcc,Date,Subject

        # Whether to always show the mimetype of an email, even when it is just a single part
        #
        # Default: false
        #always-show-mime=false

        # Define the maximum height of the mimetype switcher before a scrollbar is used.
        # The height of the mimetype switcher is restricted to half of the display
        # height. If the provided value for the height is zero, the number of parts will
        # be used as the height of the type switcher.
        #
        # Default: 0
        #max-mime-height = 0

        # Parses and extracts http links when viewing a message. Links can then be
        # accessed with the open-link command.
        #
        # Default: true
        #parse-http-links=true
      };
      compose = {
        #
        # Specifies the command to run the editor with. It will be shown in an embedded
        # terminal, though it may also launch a graphical window if the environment
        # supports it. Defaults to $EDITOR, or vi.
        #editor=

        #
        # When set, aerc will create and read .eml files for composing that have
        # non-standard \n linebreaks. This is only relevant if the used editor does not
        # support CRLF linebreaks.
        #
        #lf-editor=false

        #
        # Default header fields to display when composing a message. To display
        # multiple headers in the same row, separate them with a pipe, e.g. "To|From".
        #
        # Default: To|From,Subject
        #header-layout=To|From,Subject

        #
        # Edit headers into the text editor instead than separate fields.
        #
        # When this is true, address-book-cmd is not supported and address completion
        # is left to the editor itself. Also, displaying multiple headers on the same
        # line is not possible.
        #
        # Default: false
        edit-headers = "true";

        #
        # Sets focus to the email body when the composer window opens.
        #
        # Default: false
        #focus-body=false

        #
        # Specifies the command to be used to tab-complete email addresses. Any
        # occurrence of "%s" in the address-book-cmd will be replaced with what the
        # user has typed so far.
        #
        # The command must output the completions to standard output, one completion
        # per line. Each line must be tab-delimited, with an email address occurring as
        # the first field. Only the email address field is required. The second field,
        # if present, will be treated as the contact name. Additional fields are
        # ignored.
        #
        # This parameter can also be set per account in accounts.conf.
        #address-book-cmd=

        # Specifies the command to be used to select attachments. Any occurrence of
        # '%s' in the file-picker-cmd will be replaced with the argument <arg>
        # to :attach -m <arg>. Any occurrence of '%f' will be replaced by the
        # location of a temporary file, from which aerc will read the selected files.
        #
        # If '%f' is not present, the command must output the selected files to
        # standard output, one file per line. If it is present, then aerc does not
        # capture the standard output and instead reads the files from the temporary
        # file which should have the same format.
        #file-picker-cmd=

        #
        # Allow to address yourself when replying
        #
        # Default: true
        #reply-to-self=true

        # Warn before sending an email with an empty subject.
        #
        # Default: false
        #empty-subject-warning=false

        #
        # Warn before sending an email that matches the specified regexp but does not
        # have any attachments. Leave empty to disable this feature.
        #
        # Uses Go's regexp syntax, documented at https://golang.org/s/re2syntax. The
        # "(?im)" flags are set by default (case-insensitive and multi-line).
        #
        # Example:
        # no-attachment-warning=^[^>]*attach(ed|ment)
        #
        #no-attachment-warning=

        #
        # When set, aerc will generate "format=flowed" bodies with a content type of
        # "text/plain; format=flowed" as described in RFC3676. This format is easier to
        # handle for some mailing software, and generally just looks like ordinary
        # text. To actually make use of this format's features, you'll need support in
        # your editor.
        #
        #format-flowed=false
      };
      multipart-converters = {
        #
        # Converters allow to generate multipart/alternative messages by converting the
        # main text/plain part into any other MIME type. Only exact MIME types are
        # accepted. The commands are invoked with sh -c and are expected to output
        # valid UTF-8 text.
        #
        # Example (obviously, this requires that you write your main text/plain body
        # using the markdown syntax):
        #text/html=pandoc -f markdown -t html --standalone
      };
      filters = {
        #
        # Filters allow you to pipe an email body through a shell command to render
        # certain emails differently, e.g. highlighting them with ANSI escape codes.
        #
        # The commands are invoked with sh -c. The following folders are prepended to
        # the system $PATH to allow referencing filters from their name only:
        #
        #   ${XDG_CONFIG_HOME:-~/.config}/aerc/filters
        #   ~/.local/libexec/aerc/filters
        #   ${XDG_DATA_HOME:-~/.local/share}/aerc/filters
        #   $PREFIX/libexec/aerc/filters
        #   $PREFIX/share/aerc/filters
        #   /nix/store/b1nis22ya1nhy5fh7axsm4948r3mqsnx-aerc-0.20.1/libexec/aerc/filters
        #   /nix/store/b1nis22ya1nhy5fh7axsm4948r3mqsnx-aerc-0.20.1/share/aerc/filters
        #
        # If you want to run a program in your default $PATH which has the same name
        # as a builtin filter (e.g. /usr/bin/colorize), use its absolute path.
        #
        # The following variables are defined in the filter command environment:
        #
        #   AERC_MIME_TYPE      the part MIME type/subtype
        #   AERC_FORMAT         the part content type format= parameter
        #   AERC_FILENAME       the attachment filename (if any)
        #   AERC_SUBJECT        the message Subject header value
        #   AERC_FROM           the message From header value
        #
        # The first filter which matches the email's mimetype will be used, so order
        # them from most to least specific.
        #
        # You can also match on non-mimetypes, by prefixing with the header to match
        # against (non-case-sensitive) and a comma, e.g. subject,text will match a
        # subject which contains "text". Use header,~regex to match against a regex.
        #
        "text/plain" = "colorize";
        "text/calendar" = "calendar";
        "message/delivery-status" = "colorize";
        "message/rfc822" = "colorize";
        #text/html=pandoc -f html -t plain | colorize
        "text/html" = "! html";
        #text/html=! w3m -T text/html -I UTF-8
        #text/*=bat -fP --file-name="$AERC_FILENAME"
        #application/x-sh=bat -fP -l sh
        #image/*=catimg -w $(tput cols) -
        #subject,~Git(hub|lab)=lolcat -f
        #from,thatguywhodoesnothardwraphismessages=wrap -w 100 | colorize

        # This special filter is only used to post-process email headers when
        # [viewer].show-headers=true
        # By default, headers are piped directly into the pager.
        #
        ".headers" = "colorize";
      };
      openers = {
        #
        # Openers allow you to specify the command to use for the :open and :open-link
        # actions on a per-MIME-type basis. The :open-link URL scheme is used to
        # determine the MIME type as follows: x-scheme-handler/<scheme>.
        #
        # {} is expanded as the temporary filename or URL to be opened with proper
        # shell quoting. If it is not encountered in the command, the filename/URL will
        # be appended to the end of the command. The command will then be executed with
        # `sh -c`.
        #
        # Like [filters], openers support basic shell globbing. The first opener which
        # matches the part's MIME type (or URL scheme handler MIME type) will be used,
        # so order them from most to least specific.
        #
        # Examples:
        # x-scheme-handler/irc=hexchat
        # x-scheme-handler/http*=printf '%s' {} | wl-copy
        # text/html=surf -dfgms
        # text/plain=gvim {} +125
        # message/rfc822=thunderbird
      };

      hooks = {
        #
        # Hooks are triggered whenever the associated event occurs.

        #
        # Executed when a new email arrives in the selected folder
        #mail-received=notify-send "[$AERC_ACCOUNT/$AERC_FOLDER] New mail from $AERC_FROM_NAME" "$AERC_SUBJECT"

        #
        # Executed when mail is deleted from a folder
        #mail-deleted=mbsync "$AERC_ACCOUNT:$AERC_FOLDER" &

        #
        # Executed when aerc adds mail to a folder
        #mail-added=mbsync "$AERC_ACCOUNT:$AERC_FOLDER" &

        #
        # Executed when aerc starts
        #aerc-startup=aerc :terminal calcurse && aerc :next-tab

        #
        # Executed when aerc shuts down.
        #aerc-shutdown=

        #
        # Executed when notmuch tags are modified.
        #tag-modified=

        #
        # Executed when flags are changed on a message.
        #flag-changed=mbsync "$AERC_ACCOUNT:$AERC_FOLDER" &
      };
      templates = {
        # Templates are used to populate email bodies automatically.
        #

        # The directories where the templates are stored. It takes a colon-separated
        # list of directories. If this is unset or if a template cannot be found, the
        # following paths will be used as a fallback in that order:
        #
        #   ${XDG_CONFIG_HOME:-~/.config}/aerc/templates
        #   ${XDG_DATA_HOME:-~/.local/share}/aerc/templates
        #   /nix/store/b1nis22ya1nhy5fh7axsm4948r3mqsnx-aerc-0.20.1/share/aerc/templates
        #
        #template-dirs=

        # The default template to be used for new messages.
        #
        # default: new_message
        #new-message=new_message

        # The default template to be used for quoted replies.
        #
        # default: quoted_reply
        #quoted-reply=quoted_reply

        # The default template to be used for forward as body.
        #
        # default: forward_as_body
        #forwards=forward_as_body
      };
    };
  };
}
