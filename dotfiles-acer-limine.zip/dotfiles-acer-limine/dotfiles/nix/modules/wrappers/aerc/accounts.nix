{
  flake.wrappers.aerc =
    {
      lib,
      self',
      ...
    }:
    let
      getPasswordCmd =
        password:
        "${lib.getExe self'.packages.nushell-pa} -c 'pa show ${password} | from json | get password'";
    in
    {
      accounts = {
        "IServ Grootmoor" = {
          source = "imaps://arthur.hargassner@grootmoor.net";
          source-cred-cmd = getPasswordCmd "grootmoor.net";
          outgoing = "smtps://arthur.hargassner@grootmoor.net";
          outgoing-cred-cmd = getPasswordCmd "grootmoor.net";
          default = "INBOX";
          copy-to = "INBOX/Sent";
          from = "Arthur Hargassner <arthur.hargassner@grootmoor.net>";
          cache-headers = true;
        };

        "IServ ASG" = {
          source = "imaps://arthur.hargassner@as-gym-hh.de";
          source-cred-cmd = getPasswordCmd "grootmoor.net";
          outgoing = "smtps://arthur.hargassner@as-gym-hh.de";
          outgoing-cred-cmd = getPasswordCmd "grootmoor.net";
          default = "INBOX";
          copy-to = "INBOX/Sent";
          from = "Arthur Hargassner <arthur.hargassner@as-gym-hh.de>";
          cache-headers = true;
        };

        iCloud = {
          source = "imaps://arthur_johannes@imap.mail.me.com:993";
          source-cred-cmd = getPasswordCmd "nonweb/icloud-mail";
          outgoing = "smtp://arthur_johannes%40icloud.com@smtp.mail.me.com:587";
          outgoing-cred-cmd = getPasswordCmd "nonweb/icloud-mail";
          default = "INBOX";
          copy-to = "Sent Messages";
          from = "Arthur Hargassner <arthur_johannes@icloud.com>";
          cache-headers = true;
        };
      };
    };
}
