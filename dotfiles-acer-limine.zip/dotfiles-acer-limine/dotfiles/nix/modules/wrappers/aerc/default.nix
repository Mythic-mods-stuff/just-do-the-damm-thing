{ self, ... }:
{
  flake.wrappers.aerc =
    { wlib, ... }:
    {
      imports = [
        wlib.wrapperModules.aerc
        self.wrapperModules.inputs'
      ];
    };
}
