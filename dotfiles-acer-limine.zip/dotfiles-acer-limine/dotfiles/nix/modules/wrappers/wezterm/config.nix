{
  flake.wrappers.wezterm = {
    "wezterm.lua".path = ./wezterm.lua;
  };
}
