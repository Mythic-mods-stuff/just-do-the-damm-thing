{
  flake.wrappers.zk = {
    settings = {
      notebook.dir = "~/git/notes";
    };
  };
}
