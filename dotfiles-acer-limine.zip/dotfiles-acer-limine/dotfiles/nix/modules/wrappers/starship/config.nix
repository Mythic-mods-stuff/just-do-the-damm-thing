{
  flake.wrappers.starship =
    { pkgs, lib, ... }:
    {
      settings = {
        format = "\$os$username$localip$hostname$directory$git_branch$git_status$git_metrics\${custom.giturl}$git_commit$git_state\${custom.jj}\${custom.fill_start}$fill\${custom.fill_end}$bun\${env_var.PAGER}\${env_var.EDITOR}\${env_var.TERM}$gleam\${env_var.XDG_CURRENT_DESKTOP}$time$container$erlang$mojo$ruby$scala$direnv$haxe$ocaml$rust$swift$guix_shell$nim$spack$zig$battery$fennel$nodejs$python$package$dart$golang$kubernetes$odin$typst\${custom.screentime}$nix_shell$c$cmake$docker_context$gradle$java$helm$lua$meson$perl$php$quarto$rlang$solidity$crystal$deno$elixir$haskell$julia$kotlin$purescript$terraform$vlang$line_break$shlvl$cmd_duration$status$sudo$shell$character";
        battery = {
          disabled = true;
          display = [
            {
              style = "bold fg:green";
              threshold = 100;
            }
            {
              style = "bold fg:yellow";
              threshold = 50;
            }
            {
              style = "bold fg:red";
              threshold = 20;
            }
          ];
        };
        bun = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:rosewater";
          symbol = " ";
          version_format = "$raw";
        };
        c = {
          format = "[$symbol($version(-$name) )]($style)";
          style = "bold fg:blue";
          symbol = " ";
          version_format = "$raw";
        };
        character = {
          disabled = true;
          error_symbol = "[❯❯❯](bold fg:red)";
          format = "$symbol ";
          success_symbol = "[❯](bold fg:red)[❯](bold fg:yellow)[❯](bold fg:green)";
        };
        cmake = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:blue";
          symbol = " ";
          version_format = "$raw";
        };
        cmd_duration = {
          format = "[󱎫 $duration]($style) ";
          min_time = 0;
          style = "bold fg:yellow";
        };
        conda = {
          format = "[$symbol$environment]($style) ";
          style = "bold fg:green";
          symbol = "conda ";
          truncation_length = 1;
        };
        container = {
          format = "[$symbol \\[$name\\]]($style) ";
          style = "bold fg:red";
          symbol = "⬢";
        };
        crystal = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:lavender";
          symbol = " ";
          version_format = "$raw";
        };
        custom = {
          fill_end = {
            description = "Display a end icon for the fill module.";
            disabled = true;
            format = "[$symbol]($style)";
            style = "bold fg:maroon";
            symbol = "┫ ";
            when = true;
          };
          fill_start = {
            description = "Display a start icon for the fill module.";
            disabled = true;
            format = "[$symbol]($style)";
            style = "bold fg:maroon";
            symbol = "┣";
            when = true;
          };
          giturl = {
            command = "source ~/.config/nushell/cmds.nu; git-remote-icon";
            description = "Display symbol for remote Git server";
            disabled = true;
            format = "[$symbol($output )]($style)";
            ignore_timeout = true;
            require_repo = true;
            shell = [
              "nu"
              "-c"
            ];
            style = "bold fg:peach";
            symbol = " ";
            unsafe_no_escape = true;
            when = true;
          };
          screentime = {
            command = "uv run /home/ruhtra/scripts/src/screen_time.py get-time";
            description = "Display the current screen time measured by the screen_time script.";
            disabled = true;
            format = "[$symbol($output )]($style)";
            ignore_timeout = true;
            style = "bold fg:sapphire";
            symbol = " ";
            when = true;
          };
          jj = {
            when = "${lib.getExe pkgs.jj-starship} detect";
            shell = [ "${lib.getExe pkgs.jj-starship}" ];
            format = "$output ";
            disabled = false;
          };
        };
        dart = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:sky";
          symbol = " ";
          version_format = "$raw";
        };
        deno = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:lavender";
          symbol = "deno ";
          version_format = "$raw";
        };
        directory = {
          format = "[$read_only]($read_only_style)[$path ]($style)";
          home_symbol = " ";
          read_only = " ";
          read_only_style = "bold fg:red";
          style = "bold fg:maroon";
          substitutions = {
            Desktop = " ";
            Documents = "󰈙 ";
            Downloads = " ";
            Music = "󰝚 ";
            Pictures = " ";
            Programming = "󰲋 ";
            Videos = " ";
          };
          truncate_to_repo = false;
          truncation_length = -1;
          truncation_symbol = " /";
          use_os_path_sep = false;
        };
        direnv = {
          allowed_msg = " ";
          denied_msg = " ";
          disabled = false;
          format = "[$loaded$allowed$symbol]($style) ";
          loaded_msg = " ";
          not_allowed_msg = " ";
          style = "bold fg:peach";
          symbol = "env";
          unloaded_msg = " ";
        };
        docker_context = {
          format = "[$symbol$context]($style)";
          style = "bold fg:blue";
          symbol = " ";
        };
        elixir = {
          format = "[$symbol($version \\(OTP $otp_version\\) )]($style)";
          style = "bold fg:lavender";
          symbol = " ";
          version_format = "$raw";
        };
        elm = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:sapphire";
          symbol = " ";
          version_format = "$raw";
        };
        env_var = {
          EDITOR = {
            description = "Display the EDITOR environment variable";
            disabled = true;
            format = "[$symbol$env_value]($style) ";
            style = "bold fg:flamingo";
            symbol = " ";
          };
          PAGER = {
            description = "Display the PAGER environment variable";
            disabled = true;
            format = "[$symbol$env_value]($style) ";
            style = "bold fg:rosewater";
            symbol = " ";
          };
          TERM = {
            description = "Display the TERM environment variable";
            disabled = true;
            format = "[$symbol$env_value]($style) ";
            style = "bold fg:pink";
            symbol = " ";
          };
          XDG_CURRENT_DESKTOP = {
            description = "Display the XDG_CURRENT_DESKTOP environment variable";
            disabled = true;
            format = "[$symbol$env_value]($style) ";
            style = "bold fg:mauve";
            symbol = " ";
          };
        };
        erlang = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:red";
          symbol = " ";
          version_format = "$raw";
        };
        fennel = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:green";
          symbol = " ";
          version_format = "$raw";
        };
        fill = {
          disabled = false;
          style = "bold fg:maroon";
          symbol = " ";
        };
        git_branch = {
          disabled = true;
          format = "[$symbol$branch(/$remote_branch)]($style) ";
          only_attached = true;
          style = "bold fg:teal";
          symbol = " ";
        };
        git_commit = {
          disabled = true;
          format = " [\${hash}(@$tag)]($style) ";
          style = "bold fg:sky";
          tag_disabled = false;
          tag_symbol = "";
        };
        git_metrics = {
          added_style = "bold fg:green";
          deleted_style = "bold fg:red";
          disabled = true;
          format = "[ $added]($added_style) [ $deleted]($deleted_style) ";
          ignore_submodules = true;
        };
        git_state = {
          am = "󰶍 ";
          am_or_rebase = "󰶍 /󱁊 ";
          bisect = "bisecting";
          cherry_pick = " -picking";
          disabled = true;
          format = "[ $state( $progress_current/$progress_total)]($style) ";
          merge = " -ing";
          rebase = "󱁊 -ing";
          revert = " -ing";
          style = "bold fg:yellow";
        };
        git_status = {
          ahead = " ";
          behind = " ";
          conflicted = " ";
          deleted = " ";
          disabled = true;
          diverged = " ";
          format = "[$all_status$ahead_behind]($style) ";
          modified = " ";
          renamed = " ";
          staged = " ";
          stashed = " ";
          style = "bold fg:sapphire";
          typechanged = " ";
          untracked = " ";
          up_to_date = " ";
        };
        gleam = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:pink";
          symbol = " ";
          version_format = "$raw";
        };
        golang = {
          format = "[$symbol($version )($mod_version )]($style)";
          not_capable_style = "bold fg:red";
          style = "bold fg:sky";
          symbol = "   ";
          version_format = "$raw";
        };
        gradle = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:blue";
          symbol = " ";
          version_format = "$raw";
        };
        guix_shell = {
          format = "[$symbol]($style)";
          style = "bold fg:yellow";
          symbol = " ";
        };
        haskell = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:lavender";
          symbol = " ";
        };
        haxe = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:peach";
          symbol = " ";
          version_format = "$raw";
        };
        helm = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:blue";
          symbol = "󰠳 ";
          version_format = "$raw";
        };
        hostname = {
          disabled = true;
          format = "[@$hostname$ssh_symbol]($style) ";
          ssh_only = false;
          ssh_symbol = "  ";
          style = "bold fg:peach";
          trim_at = "";
        };
        java = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:blue";
          symbol = " ";
          version_format = "$raw";
        };
        julia = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:lavender";
          symbol = " ";
          version_format = "$raw";
        };
        kotlin = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:lavender";
          symbol = " ";
          version_format = "$raw";
        };
        kubernetes = {
          disabled = false;
          format = "[$symbol$context(\\($namespace\\))]($style) ";
          style = "bold fg:sky";
          symbol = "󱃾 ";
        };
        line_break = {
          disabled = false;
        };
        localip = {
          disabled = true;
          format = "[@$localipv4]($style)";
          ssh_only = false;
          style = "bold fg:red";
        };
        lua = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:blue";
          symbol = " ";
          version_format = "$raw";
        };
        memory_usage = {
          disabled = false;
          format = "[$symbol$ram_pct(|$swap_pct)]($style) ";
          style = "bold fg:yellow";
          symbol = " ";
          threshold = 50;
        };
        meson = {
          format = "[$symbol$project]($style) ";
          style = "bold fg:blue";
          symbol = "󰔶 ";
        };
        mojo = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:red";
          symbol = " ";
        };
        nim = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:yellow";
          symbol = " ";
          version_format = "$raw";
        };
        nix_shell = {
          format = "[$symbol($name)]($style) ";
          heuristic = true;
          impure_msg = " ";
          pure_msg = " ";
          style = "bold fg:sapphire";
          symbol = " ";
          unknown_msg = " ";
        };
        nodejs = {
          format = "[$symbol($version )]($style)";
          not_capable_style = "bold fg:red";
          style = "bold fg:green";
          symbol = " ";
          version_format = "$raw";
        };
        ocaml = {
          format = "[$symbol($version )(\\($switch_indicator$switch_name\\) )]($style)";
          global_switch_indicator = "*";
          local_switch_indicator = ".";
          style = "bold fg:peach";
          symbol = " ";
          version_format = "$raw";
        };
        odin = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:sky";
          symbol = "󰱥 ";
        };
        os = {
          disabled = true;
          format = "$symbol[$type]($style) ";
          style = "bold fg:text";
          symbols = {
            AIX = "[ ](bold fg:green)";
            AlmaLinux = "[ ](bold fg:sapphire)";
            Alpaquita = "[ ](bold fg:green)";
            Alpine = "[ ](bold fg:sapphire)";
            Amazon = "[ ](bold fg:mauve)";
            Android = "[ ](bold fg:green)";
            Arch = "[ ](bold fg:blue)";
            Artix = "[ ](bold fg:teal) ";
            CentOS = "[ ](bold fg:lavender)";
            Debian = "[ ](bold fg:maroon)";
            DragonFly = "[ ](bold fg:green)";
            Emscripten = "[ ](bold fg:green)";
            EndeavourOS = "[ ](bold fg:lavender)";
            Fedora = "[ ](bold fg:sky)";
            FreeBSD = "[ ](bold fg:red)";
            Garuda = "[ ](bold fg:blue)";
            Gentoo = "[ ](blod fg:lavender)";
            HardenedBSD = "[ ](bold fg:blue)";
            Illumos = "[ ](bold fg:peach)";
            Kali = "[ ](bold fg:sky)";
            Linux = "[ ](bold fg:yellow)";
            Mabox = "[ ](bold fg:green)";
            Macos = "[ ](bold fg:text)";
            Manjaro = "[ ](bold fg:green)";
            Mariner = "[󰞍 ](bold fg:blue)";
            MidnightBSD = "[ ](bold fg:blue)";
            Mint = "[󰣭 ](bold fg:green)";
            NetBSD = "[ ](bold fg:peach)";
            NixOS = "[ ](bold fg:sky)";
            OpenBSD = "[ ](bold fg:yellow)";
            OpenCloudOS = "[ ](bold fg:sky)";
            OracleLinux = "[ ](bold fg:red)";
            Pop = "[ ](bold fg:teal)";
            Raspbian = "[ ](bold fg:red)";
            RedHatEnterprise = "[ ](bold fg:red)";
            Redhat = "[ ](bold fg:red)";
            Redox = "[󰰠 ](bold fg:text)";
            RockyLinux = "[ ](bold fg:teal)";
            SUSE = "[ ](bold fg:green)";
            Solus = "[ ](bold fg:lavender)";
            Ubuntu = "[ ](bold fg:peach)";
            Ultramarine = "[ ](bold fg:blue)";
            Unknown = "[ ](bold fg:red)";
            Void = "[ ](bold fg:teal)";
            Windows = "[ ](bold fg:sky)";
            openEuler = "[󰏒 ](bold fg:blue)";
            openSUSE = "[ ](bold fg:teal)";
          };
        };
        package = {
          display_private = true;
          format = "[$symbol$version]($style) ";
          style = "bold fg:teal";
          symbol = " ";
          version_format = "$raw";
        };
        perl = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:blue";
          symbol = " ";
          version_format = "$raw";
        };
        php = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:blue";
          symbol = "php ";
          version_format = "$raw";
        };
        purescript = {
          format = "[$symbol($verson )]($style)";
          style = "bold fg:lavender";
          symbol = " ";
          version_format = "$raw";
        };
        python = {
          format = "[$symbol($virtualenv )($version )]($style)";
          python_binary = [ "python3" ];
          style = "bold fg:green";
          symbol = " ";
          version_format = "$raw";
        };
        quarto = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:blue";
          symbol = "󰸳 ";
          version_format = "$raw";
        };
        rlang = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:blue";
          symbol = " ";
          version_format = "$raw";
        };
        ruby = {
          format = "[$symbol($version )($gemset )]($style)";
          style = "bold fg:red";
          symbol = "󰴭 ";
          version_format = "$raw";
        };
        rust = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:peach";
          symbol = " ";
        };
        scala = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:maroon";
          symbol = " ";
          version_format = "$raw";
        };
        shell = {
          bash_indicator = "[ba](bold fg:text)";
          cmd_indicator = "[cmd](fg:subtext1)";
          disabled = false;
          elvish_indicator = "[elvi](bold fg:green)";
          fish_indicator = "[fi](bold fg:blue)";
          format = "$indicator[sh]($style) ";
          ion_indicator = "[ion](bold fg:sapphire)";
          nu_indicator = "[nu](bold fg:teal)";
          powershell_indicator = "[power](bold fg:lavender)";
          style = "fg:text";
          tcsh_indicator = "[tc](bold fg:red)";
          unknown_indicator = "[ ](bold fg:red)";
          xonsh_indicator = "[xon](bold fg:sky)";
          zsh_indicator = "[z](bold fg:peach)";
        };
        shlvl = {
          disabled = false;
          format = "[$symbol]($style) ";
          repeat = true;
          style = "bold fg:yellow";
          symbol = "";
          threshold = 0;
        };
        solidity = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:blue";
          symbol = " ";
          version_format = "$raw";
        };
        spack = {
          format = "via [$symbol$environment]($style) ";
          style = "bold fg:yellow";
          symbol = "󰰣 ";
        };
        status = {
          disabled = false;
          format = "[$symbol$status]($style) ";
          not_executable_symbol = " ";
          not_found_symbol = " ";
          sigint_symbol = " ";
          signal_symbol = " ";
          style = "bold fg:red";
          symbol = " ";
        };
        sudo = {
          disabled = false;
          format = "[$symbol]($style)";
          style = "bold fg:red";
          symbol = " ";
        };
        swift = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:peach";
          symbol = " ";
          version_format = "$raw";
        };
        terraform = {
          format = "[$symbol$workspace]($style)";
          style = "bold fg:lavender";
          symbol = " ";
          version_format = "$raw";
        };
        time = {
          disabled = false;
          format = "[ $time]($style) ";
          style = "bold fg:mauve";
          use_12hr = false;
        };
        typst = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:sky";
          symbol = " ";
          version_format = "$raw";
        };
        username = {
          disabled = true;
          format = "[$user]($style)";
          show_always = true;
          style_root = "bold fg:red";
          style_user = "bold fg:maroon";
        };
        vlang = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:lavender";
          symbol = " ";
          version_format = "$raw";
        };
        zig = {
          format = "[$symbol($version )]($style)";
          style = "bold fg:yellow";
          symbol = " ";
          version_format = "$raw";
        };
      };
    };
}
