{
  flake.wrappers = {
    starship =
      { wlib, ... }:
      {
        imports = [ wlib.wrapperModules.starship ];
      };
    starship-transient =
      { wlib, ... }:
      {
        imports = [ wlib.wrapperModules.starship ];
      };
  };
}
