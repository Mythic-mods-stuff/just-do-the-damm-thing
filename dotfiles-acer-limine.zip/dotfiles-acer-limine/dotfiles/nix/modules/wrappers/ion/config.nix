{
  flake.wrappers.ion.configFile.content = ''
    eval $(starship init ion)
  '';
}
