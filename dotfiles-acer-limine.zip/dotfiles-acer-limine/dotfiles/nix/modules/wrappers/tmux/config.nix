{
  flake.wrappers.tmux = { pkgs, ... }: {
    prefix = "C-Space";
    configBefore = ''
      set -g status-position top
      set -g @catppuccin_flavour "mocha"
      set -g default-terminal "foot"

      bind-key -n ^H send-keys ^W
      bind-key -n Home send-keys Escape "[H"
      bind-key -n End send-keys Escape "[F"
      # bind-key -n C-Left select-pane -L
      # bind-key -n C-Right select-pane -R
      # bind-key -n C-Up select-pane -U
      # bind-key -n C-Down select-pane -D

      set -g @vim_navigator_mapping_left "C-Left"
      set -g @vim_navigator_mapping_right "C-Right"
      set -g @vim_navigator_mapping_up "C-Up"
      set -g @vim_navigator_mapping_down "C-Down"
      # set -g @vim_navigator_mapping_prev ""  # removes the C-\ binding
      set -g @vim_navigator_pattern '(\S+/)?g?\.?(view|l?n?vim?x?|fzf)(diff)?(-wrapped)?'
    '';
    plugins = [
      {
        plugin = pkgs.tmuxPlugins.catppuccin;
      }
      {
        plugin = pkgs.tmuxPlugins.vim-tmux-navigator;
      }
    ];
  };
}
