{
  flake.wrappers.atuin =
    { wlib, ... }:
    {
      imports = [ wlib.wrapperModules.atuin ];
    };
}
