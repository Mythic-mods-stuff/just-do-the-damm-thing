{
  flake.wrappers.elvish =
    {
      lib,
      wlib,
      config,
      pkgs,
      ...
    }:
    {
      imports = [ wlib.modules.default ];
      options = {
        configFile = lib.mkOption {
          type = wlib.types.file pkgs;
          default.content = "";
          description = ''
            Configuration file for elvish.
          '';
        };
      };
      config = {
        flags = {
          "-rc" = "${config.configFile.path}";
        };
        package = lib.mkDefault pkgs.elvish;
      };
    };
}
