{
  flake.wrappers.jrnl =
    {
      wlib,
      lib,
      config,
      pkgs,
      ...
    }:
    let
      yamlFmt = pkgs.formats.yaml { };
    in
    {
      imports = [ wlib.modules.default ];
      options = {
        settings = lib.mkOption {
          type = yamlFmt.type;
          default = { };
          description = ''
            The settings of jrnl
          '';
        };
      };
      config = {
        constructFiles.configFile = {
          content = builtins.toJSON config.settings;
          relPath = "${config.binName}-config.yaml";
          builder = ''${lib.getExe' pkgs.remarshal "json2yaml"} "$1" "$2"'';
        };
        flags."--config-file" = config.constructFiles.configFile.path;
        package = lib.mkDefault pkgs.jrnl;
      };
    };
}
