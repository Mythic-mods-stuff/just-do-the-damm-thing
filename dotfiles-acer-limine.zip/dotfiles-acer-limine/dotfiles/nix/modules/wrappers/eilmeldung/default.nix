{ self, ... }:
{
  flake-file.inputs.eilmeldung = {
    url = "github:christo-auer/eilmeldung";
    inputs.nixpkgs.follows = "nixpkgs";
  };
  flake.wrappers.eilmeldung =
    {
      wlib,
      lib,
      inputs',
      ...
    }:
    {
      imports = [
        wlib.modules.default
        self.wrapperModules.inputs'
      ];
      config = {
        package = lib.mkDefault inputs'.eilmeldung.packages.eilmeldung;
      };
    };
}
