{ den, ... }:
{
  den.hosts.x86_64-linux.nectarine-seed.users.nixos = { };

  den.aspects.nectarine-seed = {
    includes = [
      den.aspects.locale
      den.aspects.neo-keyboard
      den.aspects.nix-config
      den.aspects.kmscon
    ];
    nixos =
      {
        inputs',
        modulesPath,
        self',
        lib,
        ...
      }:
      {
        imports = [ "${modulesPath}/installer/cd-dvd/installation-cd-minimal.nix" ];
        environment.systemPackages = [
          inputs'.custom-packages.packages.nectarine-gardener
          self'.packages.nushell
        ];
        environment.shells = [
          self'.packages.nushell
        ];
        programs.bash.interactiveShellInit = ''
          if ! [ "$TERM" = "dumb" ] && [ -z "$BASH_EXECUTION_STRING" ]; then
            exec nu -e "sudo systemctl start install.service; journalctl -efu install.service"
          fi
        '';

        boot.initrd.luks.devices.crypted-sand-cake = {
          device = "/dev/disk/by-id/ata-Samsung_SSD_860_EVO_1TB_S4X6NF0N109083X-part2";
          # crypttabExtraOpts = [
          #   ""
          # ];
        };

        fonts.fontconfig.enable = true;

        services.udisks2.enable = true;

        environment.etc.crypttab = {
          mode = "0600";
          text = ''
            # <volume-name> <encrypted-device> [key-file] [options]
            crypted-sand-cake UUID=a857186c-9db8-493b-a469-a91bbe083cff
          '';
        };

        systemd.services.install = {
          enable = true;
          # after = [ "default.target" ];
          # wantedBy = [ "default.target" ];
          serviceConfig = {
            ExecStart = "${lib.getExe inputs'.custom-packages.packages.nectarine-gardener} plant";
          };
        };
      };
  };
}
