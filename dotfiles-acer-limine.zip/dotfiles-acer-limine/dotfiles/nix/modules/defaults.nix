{ lib, den, ... }:
{
  den.default = {
    includes = [
      den.batteries.self'
      den.batteries.inputs'
    ];
    nixos.system.stateVersion = "24.05";
  };
  den.schema.user.classes = lib.mkDefault [ "hjem" ];
  den.schema.host.hjem.enable = true;
}
