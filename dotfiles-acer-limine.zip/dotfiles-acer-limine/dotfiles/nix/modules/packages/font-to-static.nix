{
  perSystem =
    { pkgs, ... }:
    {
      packages.font-to-static = pkgs.writeShellApplication {
        name = "font-to-static";
        runtimeInputs = [ pkgs.python3Packages.fonttools ];
        text = ''
          src="$1"
          name="$(basename "$src" '.ttf')"
          for wght in 100 200 300 400 500 600 700 800 900; do
            fonttools varLib.instancer -o "$name-$wght.ttf" "$src" wght="$wght"
          done
        '';
      };
    };
}
