{
  perSystem = { pkgs, ... }: {
    packages.homelab-ca-crt = pkgs.callPackage (
      { writeText }: writeText "homelab-ca.crt" (builtins.readFile ./homelab-ca.crt)
    ) { };
  };
}
