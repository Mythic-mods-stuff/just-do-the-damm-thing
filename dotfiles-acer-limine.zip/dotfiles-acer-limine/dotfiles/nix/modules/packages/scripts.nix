{ inputs, ... }:
{
  perSystem =
    {
      pkgs,
      lib,
      self',
      inputs',
      ...
    }:
    let
      writeNushellApplication =
        inputs.nuenv.lib.mkNushellScriptApplication pkgs.nushell pkgs.writeTextFile
          pkgs.lib;
      passwordass = inputs'.custom-packages.packages.passwordass;
      nushell = self'.packages.nushell;
      writeCustomNushellApplication =
        inputs.nuenv.lib.mkNushellScriptApplication nushell pkgs.writeTextFile
          pkgs.lib;
      scripts = {
        script-auto-kb-neo = writeNushellApplication {
          name = "script-auto-kb-neo";
          text = ''
            let devices = (
              libinput list-devices
                | split row "\n\n"
                | each {split row "\n"}
                | each {each {split row ": "}
                | where {($in | length) > 1}}
                | str trim
                | each {into record}
            )
            let device = (
              $devices
                | where Device == kanata
                | get 0
            )
            (
              libinput debug-events --device $device.Kernel
                | lines
                | each {localectl set-x11-keymap "de" "pc104" "neo"}
            )
          '';
          runtimeInputs = [
            pkgs.libinput
            pkgs.systemd
          ];
        };
        script-auto-kb-us = writeNushellApplication {
          name = "script-auto-kb-us";
          text = ''
            let devices = (
              libinput list-devices
                | split row "\n\n"
                | each {split row "\n"}
                | each {each {split row ": "}
                | where {($in | length) > 1}}
                | str trim
                | each {into record}
            )
            let device = (
              $devices
                | where Device == "Keebart Corne Choc Pro"
                | get 0
            )
            (
              libinput debug-events --device $device.Kernel
                | lines
                | each {localectl set-x11-keymap "us" "pc104" ""}
            )
          '';
          runtimeInputs = [
            pkgs.libinput
            pkgs.systemd
          ];
        };
        script-battery = writeNushellApplication {
          name = "script-battery";
          text = ''
            let battery = upower -i /org/freedesktop/UPower/devices/battery_BAT0 | jc --upower | from json | get 0.detail
            let percentage = $battery | get percentage | into int
            let codes = (
              if $percentage == 100 {
                [$"(ansi green_bold)" "󰁹"]
              }
              else if $percentage >= 90 {
                [$"(ansi green)" "󰂂"]
              }
              else if $percentage >= 80 {
                [$"(ansi green)" "󰂁"]
              }
              else if $percentage >= 70 {
                ["" "󰂀"]
              }
              else if $percentage >= 60 {
                ["" "󰁿"]
              }
              else if $percentage >= 50 {
                ["" "󰁾"]
              }
              else if $percentage >= 40 {
                ["" "󰁽"]
              }
              else if $percentage >= 30 {
                [$"(ansi yellow)" "󰁼"]
              }
              else if $percentage >= 20 {
                [$"(ansi red)" "󰁻"]
              }
              else if $percentage >= 10 {
                [$"(ansi red_bold)" "󰁺"]
              }
              else if $percentage >= 0 {
                [$"(ansi red_bold)(ansi attr_blink)" "󰂎"]
              }
            )
            let lightning = (
              if ($battery | get state) != "discharging" {
                "󱐋"
              } else {
                ""
              }
            )
            print $"($codes | insert 1 $lightning | str join) ($percentage)%(ansi reset)"
          '';
          runtimeInputs = [
            pkgs.upower
            pkgs.jc
          ];
        };
        script-askpass = writeNushellApplication {
          name = "script-askpass";
          text = ''
            pa s $env.SSH_ASKPASS_PASS_TO_GET | from json | get password
          '';
          runtimeInputs = [
            passwordass
          ];
        };
        script-launcher-emoji = writeNushellApplication {
          name = "script-launcher-emoji";
          text = ''
            bemoji --type --noline --download all
          '';
          runtimeInputs = [
            self'.packages.fuzzel
            pkgs.wtype
            pkgs.bemoji
          ];
        };
        script-launcher-pa = writeNushellApplication {
          name = "script-launcher-pa";
          text = ''
            source ${self'.packages.nushell}/nu-config/passwordass.nu
            let pass = (pa list | fuzzel --dmenu)
            try {
              pa a $pass
            }

            pa s $pass | get password | wtype $in
          '';
          runtimeInputs = [
            self'.packages.fuzzel
            pkgs.wtype
            passwordass
          ];
        };
        script-launcher-pa-choose = writeNushellApplication {
          name = "script-launcher-pa-choose";
          text = ''
            source ${self'.packages.nushell}/nu-config/passwordass.nu
            let pass = (pa list | fuzzel --dmenu)
            try {
              pa a $pass
            }

            let keys = pa s $pass | transpose keys values | get keys
            mut key = ""
            while not ($key in $keys) {
              $key = $keys | str join "\n" | fuzzel --dmenu
            }

            pa s $pass | get $key | wtype $in
          '';
          runtimeInputs = [
            self'.packages.fuzzel
            pkgs.wtype
            passwordass
          ];
        };
        script-launcher-pa-autofill = writeNushellApplication {
          name = "script-launcher-pa-autofill";
          text = ''
            source ${self'.packages.nushell}/nu-config/passwordass.nu
            let pass = (pa list | fuzzel --dmenu)
            pa f $pass
          '';
          runtimeInputs = [
            self'.packages.fuzzel
            pkgs.wtype
            passwordass
          ];
        };
        script-write-text-file = writeNushellApplication {
          name = "script-write-text-file";
          text = ''
            def main [filename: path] {
            $env.TEXT | save -f $filename
            }
          '';
        };
        script-toggle-tmp-term = writeNushellApplication {
          name = "script-toggle-tmp-term";
          text = ''
            let data = niri msg --json windows | from json | where app_id == foot-floating
            if ($data | length) != 0 {
              $data.pid | each {kill $in}
            } else {
              foot --app-id foot-floating -- zellij attach --create tmp
            }
          '';
          runtimeInputs = [
            pkgs.niri
            self'.packages.wezterm
            pkgs.zellij
          ];
        };
        script-toggle-waybar = writeNushellApplication {
          name = "script-toggle-waybar";
          text = ''
            let waybars = ps | find waybar
            let waybar_already_started = ($waybars | length) > 0
            if $waybar_already_started {
            	$waybars | each {|it| kill $it.pid}
            } else {
            	waybar
            }
          '';
          runtimeInputs = [
            self'.packages.waybar
          ];
        };
        script-zellij-shell = writeNushellApplication {
          name = "script-zellij-shell";
          text = ''
            $env.SHLVL = 0
            microfetch
            ${lib.getExe nushell}
          '';
          runtimeInputs = [
            pkgs.microfetch
          ];
        };
      };
    in
    {
      packages = scripts // {
        scripts = pkgs.buildEnv {
          name = "scripts";
          paths = builtins.attrValues scripts;
        };
      };
    };
  flake-file.inputs.nuenv = {
    url = "github:xav-ie/nuenv";
    inputs = {
      nixpkgs.follows = "nixpkgs";
      systems.follows = "systems";
    };
  };
}
