{
  perSystem = { pkgs, ... }: {
    packages.passage-secret-service = pkgs.callPackage (
      {
        buildGoModule,
        fetchFromGitHub,
      }:
      buildGoModule (finalAttrs: {
        pname = "passage-secret-service";
        version = "0.1.0";

        src = fetchFromGitHub {
          owner = "pinpox";
          repo = "passage-secret-service";
          rev = "bd454921861d6819ea44ac7badab6ed0e23421f9";
          hash = "sha256-T5YLeVqYGBC/d839ZjS2rjt8fD5P/oe77PYinLDJm/M=";
        };

        vendorHash = "sha256-79nyOOG7DDC2tAI2iXWqefvitLHUXp3yQCV3eNLuO1w=";

        meta = {
          description = "Freedesktop Secret Service provider using passage (age encryption)";
          homepage = "https://github.com/pinpox/passage-secret-service";
        };
      })
    ) { };
  };
}
