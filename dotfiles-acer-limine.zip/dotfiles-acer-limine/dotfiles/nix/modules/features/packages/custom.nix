{
  den.aspects.packages._.custom.hjem =
    { self', ... }:
    {
      packages = builtins.attrValues {
        inherit (self'.packages)
          nushell
          neovim
          aerc
          fastfetch
          helix
          jujutsu
          waybar
          wl-kbptr
          iamb
          tmux
          ;
      };
    };
}
