{
  den.aspects.packages._.rice.hjem =
    { pkgs, self', ... }:
    {
      packages = [
        pkgs.brightnessctl
        pkgs.swaynotificationcenter
        pkgs.hyprlock
        self'.packages.fuzzel
        pkgs.fyi
        pkgs.wev
        pkgs.wlr-which-key
        self'.packages.swaylock
      ];
    };
}
