{
  den.aspects.packages._.tui.hjem =
    { pkgs, self', ... }:
    {
      packages = [
        self'.packages.yazi
        self'.packages.cava
        pkgs.zellij
        pkgs.spotify-player
        pkgs.gurk-rs
        pkgs.ku
      ];
    };
}
