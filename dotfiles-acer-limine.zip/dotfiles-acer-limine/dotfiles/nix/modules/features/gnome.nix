{
  den.aspects.gnome.nixos = {
    services = {
      desktopManager.gnome.enable = true;
      displayManager = {
        gdm.enable = true;
        defaultSession = "niri";
      };
    };
    programs.dconf.profiles.user.databases = [
      {
        lockAll = true;
        settings."org/gnome/desktop/interface".color-scheme = "prefer-dark";
      }
    ];
  };
}
