{
  den.aspects.power-saving.nixos = {
    systemd.sleep.settings.Sleep = {
      HibernateDelaySec = "3h";
      SuspendState = "mem";
    };
    powerManagement.enable = true;
    services = {
      thermald.enable = true;
      logind.settings.Login = {
        HandleLidSwitch = "suspend-then-hibernate";
        HandleLidSwitchDocked = "suspend-then-hibernate";
        HandleLidSwitchExternalPower = "suspend-then-hibernate";
        HandlePowerKey = "suspend-then-hibernate";
        HandlePowerKeyLongPress = "poweroff";
      };
    };
  };
}
