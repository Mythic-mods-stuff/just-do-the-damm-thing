{
  den.aspects.limine.nixos =
    { pkgs, ... }:
    {
      boot.loader.limine = {
        enable = true;
        maxGenerations = 30;
        efiSupport = true;
        extraEntries = ''
          /Windows 11 :-(
            protocol: efi
            path: uuid(b19bf498-bb05-4013-a10e-81d987cf0d47):/EFI/Microsoft/Boot/bootmgfw.efi
          /Shutdown
            cmdline: halt
          /Reboot
            cmdline: reboot
        '';
        style = {
          wallpapers = [
            pkgs.nixos-artwork.wallpapers.catppuccin-mocha.kdeFilePath
          ];
          wallpaperStyle = "centered";
          backdrop = "1E1E2E";
          interface = {
            resolution = "1920x1080";
            brandingColor = 1;
            branding = "Pancake Appletree's nectarine-tree";
          };
          graphicalTerminal = {
            palette = "1e1e2e;f38ba8;a6e3a1;eba0ac;89b4fa;cba6f7;89dceb;cdd6f4"; # Or see the Catppuccin style guide
            brightPalette = "1e1e2e;f38ba8;a6e3a1;eba0ac;89b4fa;cba6f7;89dceb;cdd6f4";
            marginGradient = 20;
            margin = 4;
            foreground = "b4befe";
            brightForeground = "cdd6f4";
            font = {
              spacing = 2;
              scale = "2x2";
            };
          };
        };
      };
    };
}
