{
  den.aspects.nix-config.nixos = {
    nix.settings = {
      experimental-features = [
        "nix-command"
        "flakes"
        "pipe-operators"
      ];
      keep-outputs = true;
      keep-derivations = true;
    };
  };
}
