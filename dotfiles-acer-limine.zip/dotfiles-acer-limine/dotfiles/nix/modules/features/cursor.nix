{
  den.aspects.cursor.hjem =
    { pkgs, ... }:
    {
      files =
        let
          index-theme = pkgs.writeText "index.theme" ''
            [Icon Theme]
            Name=Default
            Comment=Default Cursor Theme
            Inherits=Fuchsia-Red
          '';
          fuchsia-cursor = "${
            pkgs.fuchsia-cursor.override { themeVariants = [ "Fuchsia-Red" ]; }
          }/share/icons/Fuchsia-Red";
        in
        {
          ".icons/Fuchsia-Red".source = fuchsia-cursor;
          ".icons/default/index.theme".source = index-theme;
          ".local/share/icons/Fuchsia-Red".source = fuchsia-cursor;
          ".local/share/icons/default/index.theme".source = index-theme;
          ".Xresources".text = ''
            Xcursor.size: 24
            Xcursor.theme: Fuchsia-Red
          '';
        };
    };
}
