{ den, inputs, ... }:
{
  flake-file.inputs.lanzaboote = {
    url = "github:nix-community/lanzaboote/v1.1.0";
    inputs.nixpkgs.follows = "nixpkgs";
  };
  den.aspects.secure-boot = {
    includes = [ den.aspects.systemd-boot ];
    hjem =
      { pkgs, ... }:
      {
        packages = [
          pkgs.sbctl
        ];
      };
    nixos =
      { lib, ... }:
      {
        imports = [ inputs.lanzaboote.nixosModules.lanzaboote ];

        boot = {
          loader.systemd-boot.enable = lib.mkForce false;
          lanzaboote = {
            enable = true;
            pkiBundle = "/var/lib/sbctl";
            autoGenerateKeys.enable = true;
            autoEnrollKeys = {
              enable = true;
              autoReboot = true;
            };
          };
        };
        systemd.services.generate-sb-keys.unitConfig.ConditionPathExists =
          lib.mkForce "!/var/lib/sbctl/keys";
      };
  };
}
