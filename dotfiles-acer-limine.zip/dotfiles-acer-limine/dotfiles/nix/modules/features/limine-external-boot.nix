{ den, ... }:
{
  den.aspects.limine-external-boot.nixos =
    { config, pkgs, ... }:
    let
      installHook = pkgs.writeShellScript "install-nixos-for-omarchy-limine" ''
        set -euo pipefail

        if [ "$#" -ne 1 ] || [ ! -d "$1" ]; then
          echo "Expected the built NixOS system toplevel as argument" >&2
          exit 1
        fi

        # Fail closed unless /boot is the known, existing Omarchy ESP.
        actual_source="$(${pkgs.util-linux}/bin/findmnt --noheadings --output SOURCE --target /boot)"
        actual_source="$(${pkgs.coreutils}/bin/readlink -f "$actual_source")"
        expected_source="$(${pkgs.coreutils}/bin/readlink -f /dev/disk/by-uuid/A282-91EC)"
        if [ -z "$actual_source" ] || [ "$actual_source" != "$expected_source" ]; then
          echo "Refusing to write boot files: /boot is not the expected Omarchy ESP (A282-91EC)." >&2
          exit 1
        fi

        destination=/boot/EFI/NixOS
        ${pkgs.coreutils}/bin/install -d -m 0755 "$destination"
        staging="$(${pkgs.coreutils}/bin/mktemp -d "$destination/.staging.XXXXXX")"
        trap '${pkgs.coreutils}/bin/rm -rf "$staging"' EXIT

        ${pkgs.coreutils}/bin/install -m 0644 \
          "${config.system.build.kernel}/${config.system.boot.loader.kernelFile}" \
          "$staging/vmlinuz"
        ${pkgs.coreutils}/bin/install -m 0644 \
          "${config.system.build.initialRamdisk}/${config.system.boot.loader.initrdFile}" \
          "$staging/initrd"

        # Keep the previous working pair for a manual fallback Limine entry.
        if [ -s "$destination/vmlinuz" ] && [ -s "$destination/initrd" ]; then
          ${pkgs.coreutils}/bin/install -m 0644 "$destination/vmlinuz" "$staging/vmlinuz.previous"
          ${pkgs.coreutils}/bin/install -m 0644 "$destination/initrd" "$staging/initrd.previous"
          ${pkgs.coreutils}/bin/mv -f "$staging/vmlinuz.previous" "$destination/vmlinuz.previous"
          ${pkgs.coreutils}/bin/mv -f "$staging/initrd.previous" "$destination/initrd.previous"
        fi

        ${pkgs.coreutils}/bin/mv -f "$staging/vmlinuz" "$destination/vmlinuz"
        ${pkgs.coreutils}/bin/mv -f "$staging/initrd" "$destination/initrd"
        ${pkgs.coreutils}/bin/sync
      '';
    in
    {
      boot.loader.efi = {
        efiSysMountPoint = "/boot";
        canTouchEfiVariables = false;
      };
      boot.loader.external = {
        enable = true;
        inherit installHook;
      };
    };
}
