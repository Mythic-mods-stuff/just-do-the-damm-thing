{
  den.aspects.sudo-rs.nixos = {
    security.sudo-rs = {
      enable = true;
      extraConfig = ''
        Defaults pwfeedback
      '';
    };
  };
}
