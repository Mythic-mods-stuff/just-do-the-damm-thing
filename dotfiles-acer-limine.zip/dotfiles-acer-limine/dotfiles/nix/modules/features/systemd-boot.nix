{
  den.aspects.systemd-boot.nixos = {
    boot.loader = {
      efi.canTouchEfiVariables = true;

      systemd-boot = {
        enable = true;
        editor = false;
        configurationLimit = 20;
      };
    };
  };
}
