{
  den.aspects.pueue.hjem =
    { pkgs, lib, ... }:
    {
      packages = [
        pkgs.pueue
      ];
      systemd.services.pueued = {
        enable = true;
        description = "pueued – CLI process scheduler and manager";
        wantedBy = [ "default.target" ];
        serviceConfig = {
          Restart = "no";
          ExecStart = "${lib.getExe' pkgs.pueue "pueued"} -vv";
        };
      };
    };
}
