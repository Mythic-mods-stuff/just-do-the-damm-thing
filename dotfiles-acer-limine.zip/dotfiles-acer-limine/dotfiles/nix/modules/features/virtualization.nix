{
  den.aspects.virtualization.nixos =
    { pkgs, ... }:
    {
      boot = {
        kernelModules = [ "kvm-intel" ];
        binfmt.emulatedSystems = [ "aarch64-linux" ];
      };
      virtualisation = {
        podman = {
          enable = true;
          defaultNetwork.settings.dns_enabled = true;
        };
        libvirtd.enable = true;
      };
      environment.systemPackages = [
        pkgs.qemu
        pkgs.quickemu
        (pkgs.lima.override { withAdditionalGuestAgents = true; })
      ];
    };
}
