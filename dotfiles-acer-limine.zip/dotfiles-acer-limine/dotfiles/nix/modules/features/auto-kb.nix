{
  den.aspects.auto-kb.nixos = { lib, self', ... }: {
    systemd.services.script-auto-kb-neo = {
      enable = true;
      description = "Automatically switch to Neo keyboard layout locale when typing on laptop keyboard";
      wantedBy = [ "default.target" ];
      serviceConfig = {
        Restart = "always";
        ExecStart = lib.getExe self'.packages.script-auto-kb-neo;
      };
    };
    systemd.services.script-auto-kb-us = {
      enable = false;
      description = "Automatically switch to US keyboard layout locale when typing on Corne keyboard";
      wantedBy = [ "default.target" ];
      serviceConfig = {
        Restart = "always";
        ExecStart = lib.getExe self'.packages.script-auto-kb-us;
      };
    };
  };
}
