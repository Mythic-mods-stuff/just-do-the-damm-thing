{
  den.aspects.xdg-default-apps.nixos = {
    xdg.mime.defaultApplications = {
      "application/pdf" = "mullvad-browser.desktop";
      "x-scheme-handler/https" = "mullvad-browser.desktop";
    };
  };
}
