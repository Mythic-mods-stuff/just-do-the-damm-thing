{ inputs, ... }:
{
  flake-file.inputs = {
    nature-wallpapers = {
      url = "github:xiwenc/nature-wallpapers";
      flake = false;
    };
  };
  den.aspects.wallpapers = {
    _.nature.hjem = {
      files = {
        "Wallpapers/nature".source = "${inputs.nature-wallpapers}/src";
      };
    };
    _.nixos-artwork.hjem =
      { pkgs, lib, ... }:
      {
        files = (
          lib.concatMapAttrs
            (name: value: {
              "Wallpapers/nixos-artwork/${name}.png".source = value.kdeFilePath;
            })
            (
              removeAttrs pkgs.nixos-artwork.wallpapers [
                "override"
                "overrideDerivation"
                "recurseForDerivations"
                "catppuccin-latte"
                "nineish-catppuccin-latte-alt"
                "nineish-catppuccin-latte"
                "nineish-solarized-dark"
                "nineish-solarized-light"
                "nineish"
                "simple-light-gray"
                "binary-white"
              ]
            )
        );
      };
  };
}
