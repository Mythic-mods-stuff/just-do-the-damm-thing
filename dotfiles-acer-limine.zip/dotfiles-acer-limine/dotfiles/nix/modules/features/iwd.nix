{
  den.aspects.iwd.nixos = {
    networking = {
      networkmanager.enable = false;
      useNetworkd = true;
      wireless = {
        enable = false;
        iwd = {
          enable = true;
          settings = {
            General = {
              EnableNetworkConfiguration = true;
              AddressRandomization = "network";
            };
          };
        };
      };
    };
  };
}
