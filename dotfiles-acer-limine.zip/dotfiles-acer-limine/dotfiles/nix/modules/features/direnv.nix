{
  den.aspects.direnv.nixos =
    { pkgs, config, ... }:
    {
      programs.direnv = {
        enable = true;
        nix-direnv = {
          enable = true;
          package = pkgs.nix-direnv.override {
            nix = config.nix.package;
          };
        };
      };
    };
}
