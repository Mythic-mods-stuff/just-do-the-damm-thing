{ den, ... }:
{
  den.aspects.acer-storage.nixos = {
    boot = {
      initrd = {
        # Replace this placeholder with `cryptsetup luksUUID /dev/nvme0n1p3`
        # after creating the NEW NixOS-only LUKS partition.
        luks.devices.crypted = {
          device = "/dev/disk/by-uuid/REPLACE_WITH_LUKS_UUID";
          allowDiscards = true;
        };
        lvm.enable = true;
        availableKernelModules = [
          "nvme"
          "xhci_pci"
          "ahci"
          "usbhid"
          "sd_mod"
        ];
      };
      resumeDevice = "/dev/pool/swap";
    };

    # This is the existing Omarchy ESP. It is mounted, never formatted.
    fileSystems."/boot" = {
      device = "/dev/disk/by-uuid/A282-91EC";
      fsType = "vfat";
      options = [ "umask=0077" ];
    };

    # These names intentionally match the original Disko + impermanence setup.
    fileSystems."/" = {
      device = "/dev/mapper/pool-root";
      fsType = "btrfs";
      options = [ "subvol=root" "compress=zstd" "noatime" ];
    };

    fileSystems."/persist" = {
      device = "/dev/mapper/pool-root";
      fsType = "btrfs";
      options = [ "subvol=persist" "compress=zstd" "noatime" ];
      neededForBoot = true;
    };

    fileSystems."/nix" = {
      device = "/dev/mapper/pool-root";
      fsType = "btrfs";
      options = [ "subvol=nix" "compress=zstd" "noatime" ];
      neededForBoot = true;
    };

    swapDevices = [ { device = "/dev/pool/swap"; } ];
  };
}
