{ inputs, self, ... }:
{
  imports = [
    inputs.disko.flakeModules.default
  ];

  flake-file.inputs.disko = {
    url = "github:nix-community/disko";
    inputs.nixpkgs.follows = "nixpkgs";
  };

  flake.diskoConfigurations =
    let
      crypted-cake =
        name:
        { device, ... }:
        {
          disko.devices = {
            disk = {
              usb-stick = {
                inherit device;
                type = "disk";
                content = {
                  type = "gpt";
                  partitions = {
                    luks = {
                      size = "100%";
                      content = {
                        type = "luks";
                        name = "crypted-${name}";
                        passwordFile = "/tmp/secret.key";
                        settings = {
                          allowDiscards = true;
                        };
                        content = {
                          type = "filesystem";
                          format = "ext4";
                          extraArgs = [
                            "-L"
                            name
                          ];
                        };
                      };
                    };
                  };
                };
              };
            };
          };
        };
    in
    {
      banana-cake = crypted-cake "banana-cake";
      starfruit-cake = crypted-cake "starfruit-cake";
      nectarine-seed = {
        disko.devices = {
          disk = {
            main = {
              device = "/dev/disk/by-id/usb-Intenso_Premium_Line_FC030ECE0855F-0:0";
              type = "disk";
              imageSize = "20G";
              content = {
                type = "gpt";
                partitions = {
                  ESP = {
                    type = "EF00";
                    size = "500M";
                    content = {
                      type = "filesystem";
                      format = "vfat";
                      mountpoint = "/boot";
                      mountOptions = [ "umask=0077" ];
                    };
                  };
                  root = {
                    size = "100%";
                    content = {
                      type = "luks";
                      name = "crypted-nectarine-seed";
                      passwordFile = "/tmp/secret.key";
                      settings.allowDiscards = true;
                      content = {
                        type = "filesystem";
                        format = "ext4";
                        mountpoint = "/";
                        extraArgs = [
                          "-L"
                          "nectarine-seed"
                        ];
                      };
                    };
                  };
                };
              };
            };
          };
        };
      };
      nectarine-tree = {
        disko.devices = {
          disk = {
            main = {
              device = "/dev/disk/by-id/nvme-eui.044a500270202613";
              type = "disk";
              content = {
                type = "gpt";
                partitions = {
                  ESP = {
                    type = "EF00";
                    size = "2G";
                    content = {
                      type = "filesystem";
                      format = "vfat";
                      mountpoint = "/boot";
                      mountOptions = [ "umask=0077" ];
                    };
                  };
                  luks = {
                    size = "100%";
                    content = {
                      type = "luks";
                      name = "crypted";
                      passwordFile = "/tmp/secret.key";
                      settings = {
                        allowDiscards = true;
                      };
                      content = {
                        type = "lvm_pv";
                        vg = "pool";
                      };
                    };
                  };
                };
              };
            };
          };
          lvm_vg = {
            pool = {
              type = "lvm_vg";
              lvs = {
                swap = {
                  size = "32G";
                  extraArgs = [
                    "-C"
                  ];
                  content = {
                    type = "swap";
                    resumeDevice = true;
                  };
                };
                root = {
                  size = "100%";
                  content = {
                    type = "btrfs";
                    extraArgs = [ "-f" ];
                    subvolumes = {
                      "/root" = {
                        mountpoint = "/";
                        mountOptions = [
                          "compress=zstd"
                          "noatime"
                        ];
                      };
                      "/persist" = {
                        mountpoint = "/persist";
                        mountOptions = [
                          "compress=zstd"
                          "noatime"
                        ];
                      };
                      "/nix" = {
                        mountpoint = "/nix";
                        mountOptions = [
                          "compress=zstd"
                          "noatime"
                        ];
                      };
                    };
                  };
                };
              };
            };
          };
        };
      };
    };

  den.aspects.disko.nixos = {
    imports = [
      inputs.disko.nixosModules.default
      self.diskoConfigurations.nectarine-tree
    ];
    fileSystems."/persist".neededForBoot = true;
  };

  den.aspects.disko-seed.nixos = {
    imports = [
      inputs.disko.nixosModules.default
      self.diskoConfigurations.nectarine-seed
    ];
  };
}
