let
  recipient = "age13jykpnkjtjsffycr6y4mtcv9u4nmjcdqdhpzp8cs50zdtuf2gyes04amhu";
  config = {
    publicKeys = [ recipient ];
    armor = true;
  };
in
{
  "builder-ed25519.age" = config;
  "builder-ed25519.pub.age" = config;
  "radicle.age" = config;
  "radicle.pub.age" = config;
  "ruhtra-id_ed25519.age" = config;
  "ruhtra-id_ed25519.pub.age" = config;
  "wireguard-key.age" = config;
  "wireguard-psk.age" = config;
  "kubeconfig.age" = config;
  "talosconfig.age" = config;
  "rclone.conf.age" = config;
  "webdav.age" = config;
  "hut-config.age" = config;
}
